extends Node3D
## Огонь жаровни: GPUParticles3D с текстурой огненных языков (атлас 4 кадра).
## Этот узел — бывший «Flame»: WorldController включает/выключает его через visible,
## поэтому огонь загорается и гаснет вместе с игровой логикой.

const FLAME_TEX: String = "res://assets/flame_tongue.png"

func _ready() -> void:
	var p: GPUParticles3D = GPUParticles3D.new()
	p.name = "FlameParticles"
	p.position = Vector3(0.0, -0.4, 0.0)
	p.amount = 28
	p.lifetime = 0.95
	p.preprocess = 0.9
	p.local_coords = false
	p.visibility_aabb = AABB(Vector3(-1.5, -1.0, -1.5), Vector3(3.0, 4.0, 3.0))
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var pm: ParticleProcessMaterial = ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = 0.26
	pm.direction = Vector3(0.0, 1.0, 0.0)
	pm.spread = 9.0
	pm.initial_velocity_min = 0.9
	pm.initial_velocity_max = 1.6
	pm.gravity = Vector3(0.0, 0.6, 0.0)
	pm.scale_min = 0.7
	pm.scale_max = 1.25
	pm.anim_offset_min = 0.0
	pm.anim_offset_max = 1.0
	var sc: Curve = Curve.new()
	sc.add_point(Vector2(0.0, 0.7))
	sc.add_point(Vector2(0.35, 1.0))
	sc.add_point(Vector2(1.0, 0.15))
	var sct: CurveTexture = CurveTexture.new()
	sct.curve = sc
	pm.scale_curve = sct
	var g: Gradient = Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.2, 0.65, 1.0])
	g.colors = PackedColorArray([Color(1.0, 0.95, 0.6, 0.0), Color(1.0, 0.85, 0.4, 1.0), Color(1.0, 0.4, 0.08, 0.85), Color(0.35, 0.06, 0.0, 0.0)])
	var gt: GradientTexture1D = GradientTexture1D.new()
	gt.gradient = g
	pm.color_ramp = gt
	p.process_material = pm
	var q: QuadMesh = QuadMesh.new()
	q.size = Vector2(0.62, 1.1)
	q.center_offset = Vector3(0.0, 0.45, 0.0)
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.billboard_keep_scale = true
	m.particles_anim_h_frames = 4
	m.particles_anim_v_frames = 1
	m.particles_anim_loop = false
	m.vertex_color_use_as_albedo = true
	m.albedo_color = Color(1.9, 1.45, 1.0, 1.0)
	m.disable_receive_shadows = true
	if ResourceLoader.exists(FLAME_TEX):
		m.albedo_texture = load(FLAME_TEX) as Texture2D
	q.material = m
	p.draw_pass_1 = q
	p.emitting = true
	add_child(p)
