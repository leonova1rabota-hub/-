extends CharacterBody3D
## Игрок от первого лица. Двойное обнаружение: RayCast3D (4.5 м) + сфера Reach (2.6 м).

const SPEED: float = 4.8
const GRAVITY: float = 22.0
const JUMP_VELOCITY: float = 7.5
const COYOTE_TIME: float = 0.15   # прыжок разрешён чуть после схода с края/склона
const JUMP_BUFFER: float = 0.2    # нажатие запоминается, если чуть раньше приземления
const LOOK_SENS: float = 0.0042
const KEY_TURN_SPEED: float = 1.9

@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D
@onready var ray: RayCast3D = $Head/Camera3D/RayCast3D
@onready var reach: Area3D = $Reach

var pitch: float = 0.0
var current_focus: Node = null
var safe_pos: Vector3 = Vector3.ZERO
var safe_timer: float = 0.0
var coyote_left: float = 0.0
var jump_buffer_left: float = 0.0

func _ready() -> void:
    add_to_group("player")
    safe_pos = global_position
    ray.add_exception(self)
    floor_max_angle = deg_to_rad(46.0)
    floor_snap_length = 0.6
    floor_stop_on_slope = true

func _input(event: InputEvent) -> void:
    if GameManager.input_locked():
        return
    if event is InputEventMouseMotion:
        var mm: InputEventMouseMotion = event
        if (mm.button_mask & MOUSE_BUTTON_MASK_RIGHT) != 0:
            GameManager.look_delta += mm.relative
    elif event is InputEventKey:
        var k: InputEventKey = event
        if k.pressed and not k.echo:
            if k.physical_keycode == KEY_E or k.physical_keycode == KEY_F or k.physical_keycode == KEY_ENTER:
                GameManager.try_interact()
            elif k.physical_keycode == KEY_SPACE or k.keycode == KEY_SPACE:
                jump_buffer_left = JUMP_BUFFER

func _physics_process(delta: float) -> void:
    var locked: bool = GameManager.input_locked()
    var iv: Vector2 = Vector2.ZERO
    var turn: float = 0.0
    if not locked:
        iv = GameManager.move_vec
        if Input.is_physical_key_pressed(KEY_W):
            iv.y -= 1.0
        if Input.is_physical_key_pressed(KEY_S):
            iv.y += 1.0
        if Input.is_physical_key_pressed(KEY_A):
            iv.x -= 1.0
        if Input.is_physical_key_pressed(KEY_D):
            iv.x += 1.0
        if Input.is_physical_key_pressed(KEY_LEFT):
            turn += 1.0
        if Input.is_physical_key_pressed(KEY_RIGHT):
            turn -= 1.0
        iv = iv.limit_length(1.0)
    var look: Vector2 = GameManager.look_delta
    GameManager.look_delta = Vector2.ZERO
    if not locked:
        rotate_y(-look.x * LOOK_SENS + turn * KEY_TURN_SPEED * delta)
        pitch = clampf(pitch - look.y * LOOK_SENS, -1.4, 1.4)
        head.rotation.x = pitch

    var dir: Vector3 = global_transform.basis * Vector3(iv.x, 0.0, iv.y)
    velocity.x = dir.x * SPEED
    velocity.z = dir.z * SPEED
    if GameManager.jump_requested:
        GameManager.jump_requested = false
        if not locked:
            jump_buffer_left = JUMP_BUFFER
    if locked:
        jump_buffer_left = 0.0

    var on_floor: bool = is_on_floor()
    if on_floor:
        coyote_left = COYOTE_TIME
        if velocity.y < 0.0:
            velocity.y = 0.0
    else:
        coyote_left = maxf(coyote_left - delta, 0.0)
        velocity.y -= GRAVITY * delta
    jump_buffer_left = maxf(jump_buffer_left - delta, 0.0)

    # Прыжок: работает и на склонах (в т.ч. на пандусе выхода из пещеры).
    if jump_buffer_left > 0.0 and coyote_left > 0.0:
        velocity.y = JUMP_VELOCITY
        jump_buffer_left = 0.0
        coyote_left = 0.0
        on_floor = false
    move_and_slide()

    safe_timer += delta
    if safe_timer > 0.8 and is_on_floor() and global_position.y > -12.0:
        safe_timer = 0.0
        safe_pos = global_position + Vector3(0.0, 0.3, 0.0)
    if global_position.y < -28.0:
        global_position = safe_pos
        velocity = Vector3.ZERO
        GameManager.show_message("Ты сорвалась вниз, но выбралась обратно!")

    _update_focus()

func _update_focus() -> void:
    var target: Node = null
    if not GameManager.input_locked():
        ray.force_raycast_update()
        if ray.is_colliding():
            var c: Object = ray.get_collider()
            if c is Node and (c as Node).is_in_group("interactable"):
                target = c as Node
        if target == null:
            target = _nearest_in_reach()
    if target != current_focus:
        current_focus = target
        GameManager.focus_target = target
        GameManager.focus_changed.emit(target)

func _nearest_in_reach() -> Node:
    var best: Node = null
    var best_score: float = 1000000.0
    var cam_pos: Vector3 = camera.global_position
    var fwd: Vector3 = -camera.global_transform.basis.z
    var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
    for b in reach.get_overlapping_bodies():
        if not (b is CollisionObject3D):
            continue
        var body: CollisionObject3D = b as CollisionObject3D
        if not body.is_in_group("interactable"):
            continue
        var to: Vector3 = body.global_position - cam_pos
        var dist: float = to.length()
        if dist < 0.05:
            continue
        var dot: float = fwd.dot(to / dist)
        if dot < 0.2:
            continue
        var excl: Array[RID] = [get_rid(), body.get_rid()]
        var query: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(cam_pos, body.global_position, 1, excl)
        var hit: Dictionary = space.intersect_ray(query)
        if not hit.is_empty():
            var col: Object = hit.get("collider")
            if not (col is Node and (col as Node).is_in_group("interactable")):
                continue
        var score: float = dist * (2.0 - dot)
        if score < best_score:
            best_score = score
            best = body
    return best
