extends CanvasLayer
## Сказочный интерфейс: баннер цели, медальоны инвентаря с иконками, кнопка действия,
## ромб-прицел, виньетка, джойстик, свиток и мини-игры.

const TRACK_W: float = 720.0
const JOY_R: float = 80.0
const SYMBOLS: Array[String] = ["СОЛНЦЕ", "ЛУНА", "ПЛАМЯ", "ЗВЕЗДА", "ВОДА"]
const RUNE_SOLUTION: Array[int] = [1, 2, 3]
const GOLD: Color = Color(1.0, 0.85, 0.35)
const ICONS: Dictionary = {
    "Ржавый топор": "icon_axe",
    "Старый ключ": "icon_key",
    "Пустой хрустальный флакон": "icon_vial",
    "Сухой факел": "icon_torch",
    "Горящий факел": "icon_torch_lit",
    "Крыло ночной совы": "icon_wing",
    "Цветок Хаоса": "icon_flower",
    "Слёзы морской ведьмы": "icon_tears",
    "Перо Феникса": "icon_feather",
    "Тяжёлый молот": "icon_hammer"
}

var tex_cache: Dictionary = {}
var vs: Vector2 = Vector2(1280.0, 720.0)
var root: Control
var banner: Control
var banner_label: Label
var banner_tween: Tween
var banner_base_x: float = 24.0
var toast_label: Label
var toast_tween: Tween
var crosshair: ColorRect
var crosshair_outer: ColorRect
var crosshair_active: bool = false
var action_root: Control
var action_glow: TextureRect
var action_btn: Button
var jump_btn: Button
var pulse_tween: Tween
var book_btn: TextureButton
var slot_buttons: Array[Button] = []
var slot_icons: Array[TextureRect] = []
var slot_labels: Array[Label] = []
var slot_sel: Array[TextureRect] = []
var joy_base: TextureRect
var joy_knob: TextureRect
var joy_index: int = -1
var look_index: int = -1
var scroll_panel: Control
var scroll_title: Label
var scroll_text: Label
var choice_box: VBoxContainer
var cauldron_panel: Control
var zone: ColorRect
var marker: ColorRect
var heat_info: Label
var heat_pos: float = 0.0
var heat_dir: float = 1.0
var heat_speed: float = 420.0
var heat_hits: int = 0
var rune_panel: Control
var rune_buttons: Array[Button] = []
var rune_state: Array[int] = [0, 0, 0]
var wood_normal: StyleBoxTexture
var wood_hover: StyleBoxTexture
var wood_pressed: StyleBoxTexture
var wood_action: StyleBoxTexture

func _ready() -> void:
    layer = 10
    _make_styles()
    root = Control.new()
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _build_vignette()
    _build_hud()
    _build_scroll()
    _build_cauldron()
    _build_runes()
    _build_toast()
    get_viewport().size_changed.connect(_layout)
    GameManager.inventory_changed.connect(_refresh_hud)
    GameManager.quest_updated.connect(_on_quest)
    GameManager.dialogue_requested.connect(_on_dialogue)
    GameManager.minigame_requested.connect(_on_minigame)
    GameManager.focus_changed.connect(_on_focus)
    GameManager.message_requested.connect(_toast)
    _layout()
    _refresh_hud()

# ------------------------------------------------------------ factories
func _tex(nm: String) -> Texture2D:
    if tex_cache.has(nm):
        return tex_cache[nm] as Texture2D
    var path: String = "res://assets/%s.svg" % nm
    var t: Texture2D = null
    if ResourceLoader.exists(path):
        t = load(path) as Texture2D
    tex_cache[nm] = t
    return t

func _trect(nm: String, sz: Vector2) -> TextureRect:
    var r: TextureRect = TextureRect.new()
    r.texture = _tex(nm)
    r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    r.stretch_mode = TextureRect.STRETCH_SCALE
    r.custom_minimum_size = sz
    r.size = sz
    r.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return r

func _make_styles() -> void:
    var tex: Texture2D = _tex("btn_wood")
    wood_normal = _make_sb(tex, Color(1.0, 1.0, 1.0), 14.0)
    wood_hover = _make_sb(tex, Color(1.15, 1.1, 0.95), 14.0)
    wood_pressed = _make_sb(tex, Color(0.7, 0.7, 0.7), 14.0)
    wood_action = _make_sb(tex, Color(1.1, 1.05, 0.9), 76.0)

func _make_sb(tex: Texture2D, tint: Color, left: float) -> StyleBoxTexture:
    var sb: StyleBoxTexture = StyleBoxTexture.new()
    sb.texture = tex
    sb.modulate_color = tint
    sb.texture_margin_left = 28.0
    sb.texture_margin_right = 28.0
    sb.texture_margin_top = 24.0
    sb.texture_margin_bottom = 24.0
    sb.content_margin_left = left
    sb.content_margin_right = 14.0
    sb.content_margin_top = 8.0
    sb.content_margin_bottom = 8.0
    return sb

func _style_button(b: Button, font_size: int, normal: StyleBoxTexture) -> void:
    b.focus_mode = Control.FOCUS_NONE
    b.add_theme_font_size_override("font_size", font_size)
    b.add_theme_color_override("font_color", Color(0.98, 0.93, 0.75))
    b.add_theme_color_override("font_hover_color", Color(1.0, 1.0, 0.85))
    b.add_theme_color_override("font_pressed_color", Color(1.0, 0.9, 0.5))
    b.add_theme_color_override("font_outline_color", Color(0.1, 0.06, 0.02))
    b.add_theme_constant_override("outline_size", 4)
    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("hover", wood_hover)
    b.add_theme_stylebox_override("pressed", wood_pressed)
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())

func _make_button(txt: String, min_size: Vector2, font_size: int) -> Button:
    var b: Button = Button.new()
    b.text = txt
    b.custom_minimum_size = min_size
    _style_button(b, font_size, wood_normal)
    return b

func _make_choice_button(txt: String) -> Button:
    var b: Button = Button.new()
    b.custom_minimum_size = Vector2(0.0, 78.0)
    _style_button(b, 20, wood_normal)
    var l: Label = Label.new()
    l.text = txt
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.add_theme_font_size_override("font_size", 20)
    l.add_theme_color_override("font_color", Color(0.98, 0.93, 0.75))
    l.add_theme_color_override("font_outline_color", Color(0.1, 0.06, 0.02))
    l.add_theme_constant_override("outline_size", 4)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    b.add_child(l)
    l.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    l.offset_left = 22.0
    l.offset_right = -22.0
    return b

func _make_label(txt: String, font_size: int, color: Color, outline: bool = true) -> Label:
    var l: Label = Label.new()
    l.text = txt
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    if outline:
        l.add_theme_color_override("font_outline_color", Color(0.05, 0.03, 0.02))
        l.add_theme_constant_override("outline_size", 6)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return l

func _anchor_region(c: Control, l: float, t: float, r: float, b: float) -> void:
    c.anchor_left = l
    c.anchor_top = t
    c.anchor_right = r
    c.anchor_bottom = b
    c.offset_left = 0.0
    c.offset_top = 0.0
    c.offset_right = 0.0
    c.offset_bottom = 0.0

func _make_dim(alpha: float) -> ColorRect:
    var dim: ColorRect = ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.0, alpha)
    dim.mouse_filter = Control.MOUSE_FILTER_STOP
    return dim

# ------------------------------------------------------------ building
func _build_vignette() -> void:
    var v: TextureRect = _trect("vignette", Vector2(512.0, 288.0))
    root.add_child(v)
    v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _build_hud() -> void:
    banner = Control.new()
    banner.custom_minimum_size = Vector2(640.0, 92.0)
    banner.size = Vector2(640.0, 92.0)
    banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(banner)
    banner.add_child(_trect("banner_bg", Vector2(640.0, 92.0)))
    var sic: TextureRect = _trect("icon_scroll", Vector2(58.0, 58.0))
    sic.position = Vector2(20.0, 17.0)
    banner.add_child(sic)
    banner_label = _make_label("", 21, Color(0.24, 0.1, 0.03), false)
    banner_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    banner_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    banner_label.position = Vector2(92.0, 12.0)
    banner_label.size = Vector2(520.0, 68.0)
    banner.add_child(banner_label)

    crosshair_outer = ColorRect.new()
    crosshair_outer.size = Vector2(22.0, 22.0)
    crosshair_outer.pivot_offset = Vector2(11.0, 11.0)
    crosshair_outer.rotation = PI / 4.0
    crosshair_outer.color = Color(1.0, 1.0, 1.0, 0.22)
    crosshair_outer.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(crosshair_outer)
    crosshair = ColorRect.new()
    crosshair.size = Vector2(10.0, 10.0)
    crosshair.pivot_offset = Vector2(5.0, 5.0)
    crosshair.rotation = PI / 4.0
    crosshair.color = Color(1.0, 1.0, 1.0, 0.9)
    crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(crosshair)

    action_root = Control.new()
    action_root.custom_minimum_size = Vector2(360.0, 100.0)
    action_root.size = Vector2(360.0, 100.0)
    action_root.pivot_offset = Vector2(180.0, 50.0)
    action_root.visible = false
    action_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(action_root)
    action_glow = _trect("glow_gold", Vector2(460.0, 170.0))
    action_glow.position = Vector2(-50.0, -35.0)
    action_root.add_child(action_glow)
    action_btn = Button.new()
    action_btn.custom_minimum_size = Vector2(360.0, 100.0)
    action_btn.size = Vector2(360.0, 100.0)
    _style_button(action_btn, 26, wood_action)
    action_btn.pressed.connect(_on_action_pressed)
    action_root.add_child(action_btn)
    var hand: TextureRect = _trect("icon_hand", Vector2(54.0, 54.0))
    hand.position = Vector2(18.0, 23.0)
    action_root.add_child(hand)

    for i in range(4):
        var b: Button = Button.new()
        b.flat = true
        b.focus_mode = Control.FOCUS_NONE
        b.custom_minimum_size = Vector2(120.0, 138.0)
        b.size = Vector2(120.0, 138.0)
        b.add_theme_stylebox_override("normal", StyleBoxEmpty.new())
        b.add_theme_stylebox_override("hover", StyleBoxEmpty.new())
        b.add_theme_stylebox_override("pressed", StyleBoxEmpty.new())
        b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
        b.pressed.connect(_on_slot_pressed.bind(i))
        root.add_child(b)
        var fr: TextureRect = _trect("slot_frame", Vector2(104.0, 104.0))
        fr.position = Vector2(8.0, 0.0)
        b.add_child(fr)
        var sel: TextureRect = _trect("slot_select", Vector2(116.0, 116.0))
        sel.position = Vector2(2.0, -6.0)
        sel.visible = false
        b.add_child(sel)
        var ic: TextureRect = _trect("icon_book", Vector2(64.0, 64.0))
        ic.position = Vector2(28.0, 20.0)
        ic.visible = false
        b.add_child(ic)
        var lb: Label = _make_label("", 12, Color(1.0, 0.95, 0.8))
        lb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        lb.position = Vector2(2.0, 102.0)
        lb.size = Vector2(116.0, 34.0)
        b.add_child(lb)
        slot_buttons.append(b)
        slot_icons.append(ic)
        slot_labels.append(lb)
        slot_sel.append(sel)

    book_btn = TextureButton.new()
    book_btn.texture_normal = _tex("icon_book")
    book_btn.ignore_texture_size = true
    book_btn.stretch_mode = TextureButton.STRETCH_SCALE
    book_btn.custom_minimum_size = Vector2(88.0, 88.0)
    book_btn.size = Vector2(88.0, 88.0)
    book_btn.focus_mode = Control.FOCUS_NONE
    book_btn.pressed.connect(_on_book_pressed)
    root.add_child(book_btn)

    joy_base = TextureRect.new()
    joy_base.texture = _tex("joystick_base")
    joy_base.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    joy_base.stretch_mode = TextureRect.STRETCH_SCALE
    joy_base.custom_minimum_size = Vector2(200.0, 200.0)
    joy_base.size = Vector2(200.0, 200.0)
    joy_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
    joy_base.modulate.a = 0.8
    root.add_child(joy_base)
    joy_knob = _trect("joystick_knob", Vector2(84.0, 84.0))
    joy_base.add_child(joy_knob)
    _reset_knob()

    jump_btn = _make_button("ПРЫЖОК", Vector2(170.0, 170.0), 24)
    jump_btn.focus_mode = Control.FOCUS_NONE
    jump_btn.modulate.a = 0.9
    jump_btn.button_down.connect(_on_jump_down)
    root.add_child(jump_btn)

func _build_scroll() -> void:
    scroll_panel = Control.new()
    scroll_panel.visible = false
    root.add_child(scroll_panel)
    scroll_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var dim: ColorRect = _make_dim(0.62)
    scroll_panel.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var bg: TextureRect = _trect("scroll_bg", Vector2(100.0, 100.0))
    scroll_panel.add_child(bg)
    _anchor_region(bg, 0.05, 0.03, 0.95, 0.97)
    var margin: MarginContainer = MarginContainer.new()
    margin.add_theme_constant_override("margin_left", 120)
    margin.add_theme_constant_override("margin_right", 120)
    margin.add_theme_constant_override("margin_top", 84)
    margin.add_theme_constant_override("margin_bottom", 76)
    scroll_panel.add_child(margin)
    _anchor_region(margin, 0.05, 0.03, 0.95, 0.97)
    var vb: VBoxContainer = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 12)
    margin.add_child(vb)
    scroll_title = _make_label("", 36, Color(0.3, 0.12, 0.04), false)
    scroll_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(scroll_title)
    var sc: ScrollContainer = ScrollContainer.new()
    sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    vb.add_child(sc)
    scroll_text = _make_label("", 24, Color(0.2, 0.11, 0.04), false)
    scroll_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    scroll_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sc.add_child(scroll_text)
    choice_box = VBoxContainer.new()
    choice_box.add_theme_constant_override("separation", 8)
    vb.add_child(choice_box)

func _build_cauldron() -> void:
    cauldron_panel = Control.new()
    cauldron_panel.visible = false
    root.add_child(cauldron_panel)
    cauldron_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var dim: ColorRect = _make_dim(0.72)
    cauldron_panel.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var cc: CenterContainer = CenterContainer.new()
    cauldron_panel.add_child(cc)
    cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var vb: VBoxContainer = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 22)
    vb.alignment = BoxContainer.ALIGNMENT_CENTER
    cc.add_child(vb)
    var title: Label = _make_label("ВАРКА ЗЕЛЬЯ", 44, Color(0.6, 1.0, 0.6))
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(title)
    var hint: Label = _make_label("Жми, когда бегунок в зелёной зоне. Нужно 3 попадания!", 24, Color(1.0, 0.95, 0.8))
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(hint)
    var track: Control = Control.new()
    track.custom_minimum_size = Vector2(TRACK_W, 90.0)
    vb.add_child(track)
    var tb: ColorRect = ColorRect.new()
    tb.color = Color(0.13, 0.08, 0.05)
    tb.size = Vector2(TRACK_W, 70.0)
    tb.position = Vector2(0.0, 10.0)
    tb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    track.add_child(tb)
    zone = ColorRect.new()
    zone.color = Color(0.25, 0.78, 0.3)
    zone.size = Vector2(150.0, 70.0)
    zone.position = Vector2(300.0, 10.0)
    zone.mouse_filter = Control.MOUSE_FILTER_IGNORE
    track.add_child(zone)
    marker = ColorRect.new()
    marker.color = Color(1.0, 0.9, 0.4)
    marker.size = Vector2(14.0, 90.0)
    marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
    track.add_child(marker)
    heat_info = _make_label("Попаданий: 0/3", 28, Color(1.0, 0.9, 0.5))
    heat_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(heat_info)
    var heat_btn: Button = _make_button("ПОДБРОСИТЬ ЖАР!", Vector2(460.0, 100.0), 36)
    heat_btn.pressed.connect(_on_heat_pressed)
    vb.add_child(heat_btn)
    var cancel: Button = _make_button("Отойти от котла", Vector2(300.0, 60.0), 22)
    cancel.pressed.connect(_on_cauldron_cancel)
    vb.add_child(cancel)

func _build_runes() -> void:
    rune_panel = Control.new()
    rune_panel.visible = false
    root.add_child(rune_panel)
    rune_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var dim: ColorRect = _make_dim(0.75)
    rune_panel.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var cc: CenterContainer = CenterContainer.new()
    rune_panel.add_child(cc)
    cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var vb: VBoxContainer = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 20)
    vb.alignment = BoxContainer.ALIGNMENT_CENTER
    cc.add_child(vb)
    var title: Label = _make_label("КАМЕННЫЕ КОЛЬЦА", 44, Color(0.6, 0.8, 1.0))
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(title)
    var hint: Label = _make_label("Вращай кольца, пока символы не совпадут с загадкой из Книги Рецептов.", 22, Color(1.0, 0.95, 0.8))
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(hint)
    var hb: HBoxContainer = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 30)
    hb.alignment = BoxContainer.ALIGNMENT_CENTER
    vb.add_child(hb)
    var ring_names: Array[String] = ["Кольцо I", "Кольцо II", "Кольцо III"]
    for i in range(3):
        var col: VBoxContainer = VBoxContainer.new()
        col.add_theme_constant_override("separation", 8)
        hb.add_child(col)
        var nm: Label = _make_label(ring_names[i], 24, Color(0.8, 0.9, 1.0))
        nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        col.add_child(nm)
        var rb: Button = _make_button(SYMBOLS[0], Vector2(210.0, 170.0), 30)
        rb.pressed.connect(_on_ring_pressed.bind(i))
        col.add_child(rb)
        rune_buttons.append(rb)
    var row: HBoxContainer = HBoxContainer.new()
    row.add_theme_constant_override("separation", 24)
    row.alignment = BoxContainer.ALIGNMENT_CENTER
    vb.add_child(row)
    var book: Button = _make_button("Книга Рецептов", Vector2(280.0, 64.0), 22)
    book.pressed.connect(_on_book_pressed)
    row.add_child(book)
    var close: Button = _make_button("Закрыть", Vector2(220.0, 64.0), 22)
    close.pressed.connect(_on_runes_close)
    row.add_child(close)

func _build_toast() -> void:
    toast_label = _make_label("", 26, Color.WHITE)
    toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    toast_label.modulate.a = 0.0
    root.add_child(toast_label)

# ------------------------------------------------------------ layout
func _layout() -> void:
    vs = get_viewport().get_visible_rect().size
    banner.position = Vector2(banner_base_x, 14.0)
    book_btn.position = Vector2(vs.x - 108.0, 14.0)
    crosshair.position = vs / 2.0 - crosshair.size / 2.0
    crosshair_outer.position = vs / 2.0 - crosshair_outer.size / 2.0
    action_root.position = Vector2((vs.x - action_root.size.x) / 2.0, vs.y * 0.56)
    var x0: float = (vs.x - 4.0 * 124.0) / 2.0
    for i in range(4):
        slot_buttons[i].position = Vector2(x0 + i * 124.0, vs.y - 148.0)
    joy_base.position = Vector2(50.0, vs.y - 260.0)
    jump_btn.position = Vector2(vs.x - 210.0, vs.y - 260.0)
    toast_label.position = Vector2(vs.x * 0.2, 124.0)
    toast_label.size = Vector2(vs.x * 0.6, 70.0)

func _reset_knob() -> void:
    joy_knob.position = (joy_base.size - joy_knob.size) / 2.0

# ------------------------------------------------------------ HUD callbacks
func _refresh_hud() -> void:
    for i in range(4):
        var has: bool = i < GameManager.inventory.size()
        if has:
            var nm: String = GameManager.inventory[i]
            slot_labels[i].text = nm
            slot_icons[i].texture = _tex(str(ICONS.get(nm, "icon_book")))
            slot_icons[i].visible = true
            slot_buttons[i].modulate = Color(1.0, 1.0, 1.0)
        else:
            slot_labels[i].text = ""
            slot_icons[i].visible = false
            slot_buttons[i].modulate = Color(0.7, 0.7, 0.7)
        slot_sel[i].visible = (i == GameManager.selected_slot)
    book_btn.visible = GameManager.book_found
    _on_focus(GameManager.focus_target)

func _on_quest(text: String) -> void:
    banner_label.text = "Цель: " + text
    if banner_tween != null and banner_tween.is_valid():
        banner_tween.kill()
    banner_label.modulate.a = 0.0
    banner.modulate = Color(1.8, 1.55, 0.9)
    banner.position.x = banner_base_x - 60.0
    banner_tween = create_tween().set_parallel(true)
    banner_tween.tween_property(banner, "position:x", banner_base_x, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    banner_tween.tween_property(banner, "modulate", Color(1.0, 1.0, 1.0), 1.0)
    banner_tween.tween_property(banner_label, "modulate:a", 1.0, 0.7)

func _set_crosshair(active: bool) -> void:
    if active == crosshair_active:
        return
    crosshair_active = active
    var tw: Tween = create_tween().set_parallel(true)
    var s: Vector2 = Vector2(1.9, 1.9) if active else Vector2.ONE
    var c: Color = GOLD if active else Color(1.0, 1.0, 1.0, 0.9)
    var c2: Color = Color(1.0, 0.85, 0.35, 0.5) if active else Color(1.0, 1.0, 1.0, 0.22)
    tw.tween_property(crosshair, "scale", s, 0.15)
    tw.tween_property(crosshair, "color", c, 0.15)
    tw.tween_property(crosshair_outer, "scale", s, 0.15)
    tw.tween_property(crosshair_outer, "color", c2, 0.15)

func _start_pulse() -> void:
    if pulse_tween != null and pulse_tween.is_valid():
        pulse_tween.kill()
    action_root.scale = Vector2.ONE
    pulse_tween = create_tween().set_loops()
    pulse_tween.tween_property(action_root, "scale", Vector2(1.06, 1.06), 0.55).set_trans(Tween.TRANS_SINE)
    pulse_tween.parallel().tween_property(action_glow, "modulate:a", 1.0, 0.55)
    pulse_tween.tween_property(action_root, "scale", Vector2.ONE, 0.55).set_trans(Tween.TRANS_SINE)
    pulse_tween.parallel().tween_property(action_glow, "modulate:a", 0.45, 0.55)

func _on_focus(target: Node) -> void:
    var active: bool = target != null and is_instance_valid(target) and not GameManager.input_locked()
    if active:
        action_btn.text = str(target.get("prompt_text"))
        if not action_root.visible:
            action_root.visible = true
            _start_pulse()
    else:
        if action_root.visible:
            action_root.visible = false
            if pulse_tween != null and pulse_tween.is_valid():
                pulse_tween.kill()
    _set_crosshair(active)

func _on_action_pressed() -> void:
    GameManager.try_interact()

func _on_book_pressed() -> void:
    GameManager.show_book()

func _on_slot_pressed(i: int) -> void:
    GameManager.selected_slot = i
    _refresh_hud()
    if i < GameManager.inventory.size():
        var nm: String = GameManager.inventory[i]
        _toast(nm + " — " + str(GameManager.item_info.get(nm, "")))

func _toast(text: String) -> void:
    toast_label.text = text
    toast_label.modulate.a = 1.0
    if toast_tween != null and toast_tween.is_valid():
        toast_tween.kill()
    toast_tween = create_tween()
    toast_tween.tween_interval(3.0)
    toast_tween.tween_property(toast_label, "modulate:a", 0.0, 0.8)

func _update_modal() -> void:
    var was: bool = GameManager.modal_open
    GameManager.modal_open = scroll_panel.visible or cauldron_panel.visible or rune_panel.visible
    if GameManager.modal_open and not was:
        joy_index = -1
        look_index = -1
        GameManager.move_vec = Vector2.ZERO
        _reset_knob()
    _on_focus(GameManager.focus_target)

# ------------------------------------------------------------ scroll / dialogue
func _on_dialogue(title: String, text: String, choices: Array) -> void:
    scroll_title.text = title
    scroll_text.text = text
    for c in choice_box.get_children():
        c.queue_free()
    var list: Array = choices
    if list.is_empty():
        list = [{"text": "ГОТОВО"}]
    for ch in list:
        var b: Button = _make_choice_button(str(ch.get("text", "ГОТОВО")))
        b.pressed.connect(_on_choice.bind(ch))
        choice_box.add_child(b)
    scroll_panel.visible = true
    _update_modal()

func _on_choice(ch: Dictionary) -> void:
    scroll_panel.visible = false
    _update_modal()
    var act: Variant = ch.get("action", null)
    if act is Callable and (act as Callable).is_valid():
        (act as Callable).call()

# ------------------------------------------------------------ minigames
func _on_minigame(type: String) -> void:
    if type == "cauldron":
        heat_hits = 0
        heat_speed = 420.0
        heat_pos = 0.0
        heat_dir = 1.0
        _randomize_zone()
        heat_info.text = "Попаданий: 0/3"
        cauldron_panel.visible = true
        _update_modal()
    elif type == "runes":
        rune_state = [0, 0, 0]
        _refresh_runes()
        rune_panel.visible = true
        _update_modal()

func _randomize_zone() -> void:
    zone.position = Vector2(randf_range(60.0, TRACK_W - 60.0 - zone.size.x), 10.0)

func _process(delta: float) -> void:
    if cauldron_panel.visible:
        heat_pos += heat_dir * heat_speed * delta
        var maxp: float = TRACK_W - marker.size.x
        if heat_pos >= maxp:
            heat_pos = maxp
            heat_dir = -1.0
        elif heat_pos <= 0.0:
            heat_pos = 0.0
            heat_dir = 1.0
        marker.position.x = heat_pos

func _on_heat_pressed() -> void:
    var c: float = heat_pos + marker.size.x * 0.5
    if c >= zone.position.x and c <= zone.position.x + zone.size.x:
        heat_hits += 1
        GameManager.play_sfx("magic")
        if heat_hits >= 3:
            cauldron_panel.visible = false
            _update_modal()
            GameManager.minigame_finished.emit("cauldron", true)
            return
        heat_speed += 120.0
        _randomize_zone()
        _toast("В точку!")
    else:
        heat_hits = maxi(0, heat_hits - 1)
        _toast("Мимо! Жар ушёл.")
    heat_info.text = "Попаданий: %d/3" % heat_hits

func _on_cauldron_cancel() -> void:
    cauldron_panel.visible = false
    _update_modal()
    GameManager.minigame_finished.emit("cauldron", false)

func _refresh_runes() -> void:
    for i in range(3):
        rune_buttons[i].text = SYMBOLS[rune_state[i]]

func _on_ring_pressed(i: int) -> void:
    rune_state[i] = (rune_state[i] + 1) % SYMBOLS.size()
    GameManager.play_sfx("pickup")
    _refresh_runes()
    var ok: bool = true
    for k in range(3):
        if rune_state[k] != RUNE_SOLUTION[k]:
            ok = false
    if ok:
        await get_tree().create_timer(0.5).timeout
        if rune_panel.visible:
            rune_panel.visible = false
            _update_modal()
            GameManager.minigame_finished.emit("runes", true)

func _on_runes_close() -> void:
    rune_panel.visible = false
    _update_modal()

# ------------------------------------------------------------ touch input
func _on_jump_down() -> void:
    if not GameManager.input_locked():
        GameManager.jump_requested = true

func _hit_ui(pos: Vector2) -> bool:
    if jump_btn.get_global_rect().has_point(pos):
        return true
    if action_root.visible and action_root.get_global_rect().has_point(pos):
        return true
    if book_btn.visible and book_btn.get_global_rect().has_point(pos):
        return true
    for b in slot_buttons:
        if b.get_global_rect().has_point(pos):
            return true
    return false

func _input(event: InputEvent) -> void:
    if GameManager.input_locked():
        return
    if event is InputEventScreenTouch:
        var t: InputEventScreenTouch = event
        if t.pressed:
            if _hit_ui(t.position):
                return
            var center: Vector2 = joy_base.global_position + joy_base.size / 2.0
            if joy_index == -1 and t.position.distance_to(center) < 170.0:
                joy_index = t.index
                _update_joy(t.position)
            elif look_index == -1 and t.position.x > vs.x * 0.5:
                look_index = t.index
        else:
            if t.index == joy_index:
                joy_index = -1
                GameManager.move_vec = Vector2.ZERO
                _reset_knob()
            if t.index == look_index:
                look_index = -1
    elif event is InputEventScreenDrag:
        var d: InputEventScreenDrag = event
        if d.index == joy_index:
            _update_joy(d.position)
        elif d.index == look_index:
            GameManager.look_delta += d.relative

func _update_joy(pos: Vector2) -> void:
    var center: Vector2 = joy_base.global_position + joy_base.size / 2.0
    var v: Vector2 = pos - center
    if v.length() > JOY_R:
        v = v.normalized() * JOY_R
    joy_knob.position = (joy_base.size - joy_knob.size) / 2.0 + v
    var n: Vector2 = v / JOY_R
    if n.length() < 0.15:
        n = Vector2.ZERO
    GameManager.move_vec = n
