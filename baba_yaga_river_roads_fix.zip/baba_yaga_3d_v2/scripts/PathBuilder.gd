extends Node3D
## Тропинки: по одной полосе Path3D + CSGPolygon3D на тропу. Полоса идёт строго по рельефу
## (высоты контрольных точек подтягиваются к земле лучом), без ступенек и без коллизии.

@export var path_material: Material

const HALF_WIDTH: float = 1.9
const TOP: float = 0.04       # верх полосы на 4 см над землёй: нет z-fighting с ландшафтом (коллизии нет)
const DEPTH: float = 0.6      # полоса уходит вглубь, чтобы бока на уклоне не висели

const TRAILS: Array = [[[0.0, 0.0, 7.0], [-1.419, 0.0, 10.38], [-3.448, 0.0, 13.586], [-5.523, 0.0, 16.779], [-7.057, 0.0, 20.127], [-7.755, 0.0, 23.713], [-7.779, 0.0, 27.492], [-7.659, 0.0, 31.312], [-8.0, 0.0, 35.0], [-9.101, 0.0, 38.43], [-9.501, 0.0, 42.12], [-9.667, 0.0, 45.897], [-10.192, 0.0, 49.54], [-11.478, 0.0, 52.902], [-13.513, 0.0, 55.986], [-15.886, 0.0, 58.945], [-18.0, 0.0, 62.0], [-19.547, 0.0, 65.602], [-22.32, 0.0, 68.59], [-24.526, 0.0, 71.862]], [[0.0, 0.0, 7.0], [4.0, 0.0, 7.0], [8.946, 0.0, 5.946], [10.0, 0.0, 1.0], [12.575, 0.0, -2.172]], [[0.0, 0.0, 7.0], [-4.0, 0.0, 6.6], [-8.0, 0.0, 5.4], [-12.0, 0.0, 4.2], [-16.0, 0.0, 3.4], [-20.0, 0.0, 2.8], [-25.386, 0.0, 2.252], [-28.604, 0.0, 0.625]], [[-45.627, 0.0, -6.03], [-47.351, 0.891, -9.97], [-50.582, 2.442, -12.529], [-55.0, 4.247, -14.0], [-56.621, 5.422, -18.574], [-60.421, 7.077, -21.188]], [[-8.0, 0.0, 35.0], [-10.787, 0.0, 37.46], [-13.294, 0.0, 40.393], [-15.918, 0.0, 43.128], [-18.987, 0.0, 45.111], [-22.551, 0.0, 46.254], [-26.357, 0.0, 46.99], [-30.0, 0.0, 48.0], [-33.098, 0.0, 49.526]], [[-46.713, 0.0, 52.946], [-49.43, 0.0, 55.311], [-52.0, 0.0, 58.0], [-55.259, 0.0, 54.523]], [[0.0, 0.0, 7.0], [4.031, 0.0, 7.394], [8.223, 0.0, 6.716], [12.359, 0.0, 6.405], [16.271, 0.0, 7.596], [20.0, 0.0, 10.0], [23.841, 0.0, 8.015], [27.827, 0.0, 7.469], [31.938, 0.0, 8.179], [36.036, 0.0, 8.764], [40.0, 0.0, 8.0], [44.384, 0.0, 9.638], [48.45, 0.0, 9.364]], [[4.0, 0.0, 7.0], [5.972, 0.0, 3.913], [7.267, 0.0, 0.625], [7.76, 0.0, -2.9], [7.753, 0.0, -6.573], [7.812, 0.0, -10.227], [8.467, 0.0, -13.704], [9.935, 0.0, -16.941], [12.0, 0.0, -20.0], [10.339, 0.0, -23.595], [9.248, 0.0, -27.266], [9.049, 0.0, -31.056], [9.558, 0.0, -34.941], [10.192, 0.0, -38.842], [10.297, 0.0, -42.673], [9.518, 0.0, -46.386], [8.0, 0.0, -50.0], [9.932, 0.0, -53.247], [11.422, 0.0, -56.588], [12.1, 0.0, -60.104], [12.033, 0.0, -63.779], [11.688, 0.0, -67.513], [11.68, 0.0, -71.176], [12.445, 0.0, -74.673]], [[-10.2, 0.0, 4.0], [-11.0, 0.0, 4.8], [-11.0, 0.0, 5.5]]]

var paths: Array = []

func _ready() -> void:
	for i in TRAILS.size():
		_make_trail(i, TRAILS[i])
	await get_tree().physics_frame
	await get_tree().physics_frame
	_snap_to_terrain()

func _make_trail(i: int, pts: Array) -> void:
	var path: Path3D = Path3D.new()
	path.name = "Trail%d" % i
	var curve: Curve3D = Curve3D.new()
	curve.bake_interval = 1.0
	var n: int = pts.size()
	for k in n:
		var p: Array = pts[k]
		var prev: Array = pts[maxi(k - 1, 0)]
		var nxt: Array = pts[mini(k + 1, n - 1)]
		var tang: Vector3 = (Vector3(float(nxt[0]), float(nxt[1]), float(nxt[2])) - Vector3(float(prev[0]), float(prev[1]), float(prev[2]))) / 6.0
		curve.add_point(Vector3(float(p[0]), float(p[1]), float(p[2])), -tang, tang)
	path.curve = curve
	add_child(path)
	paths.append(path)
	var poly: CSGPolygon3D = CSGPolygon3D.new()
	poly.name = "Strip%d" % i
	poly.polygon = PackedVector2Array([Vector2(-HALF_WIDTH, TOP), Vector2(HALF_WIDTH, TOP), Vector2(HALF_WIDTH, -DEPTH), Vector2(-HALF_WIDTH, -DEPTH)])
	poly.mode = CSGPolygon3D.MODE_PATH
	poly.path_interval_type = CSGPolygon3D.PATH_INTERVAL_DISTANCE
	poly.path_interval = 1.0
	poly.path_rotation = CSGPolygon3D.PATH_ROTATION_PATH
	poly.smooth_faces = true
	poly.use_collision = false
	poly.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if path_material != null:
		poly.material = path_material
	add_child(poly)
	poly.path_node = NodePath("../" + String(path.name))

func _snap_to_terrain() -> void:
	var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
	for path in paths:
		var p3: Path3D = path
		var curve: Curve3D = p3.curve
		for k in curve.point_count:
			var pos: Vector3 = curve.get_point_position(k)
			if absf(pos.y) < 0.01:
				continue    # ровные тропы остаются строго на земле (крыши и постройки не трогаем)
			var q: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(Vector3(pos.x, pos.y + 3.0, pos.z), Vector3(pos.x, pos.y - 6.0, pos.z))
			q.collision_mask = 1
			var hit: Dictionary = space.intersect_ray(q)
			if not hit.is_empty():
				var hp: Vector3 = hit["position"]
				if absf(hp.y - pos.y) < 0.6:    # принимаем только попадание в рельеф, не в крыши
					curve.set_point_position(k, Vector3(pos.x, hp.y, pos.z))
