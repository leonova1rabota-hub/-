extends RefCounted
## Универсальный загрузчик .glb/.gltf из res://assets/custom/models/
## Сканирует папку, определяет роль модели по имени (изба, дерево, камень,
## сундук, котёл, алтарь, подсвечник, персонаж), подгоняет масштаб и основание.

const MODEL_DIR: String = "res://assets/custom/models"

# Порядок важен: первое совпадение побеждает ("witch_house" -> house, не witch).
const ROLE_KEYS: Array = [
	["house", ["house", "hut", "cabin", "izba"]],
	["cauldron", ["cauldron", "kotel"]],
	["altar", ["altar"]],
	["candle", ["candle"]],
	["witch", ["witch", "yaga", "baba", "character"]],
	["tree", ["tree"]],
	["rock", ["rock", "stone", "boulder"]],
	["chest", ["chest"]],
	["axe", ["axe"]],
]

static func classify(file_name: String) -> String:
	var low: String = file_name.to_lower()
	for entry in ROLE_KEYS:
		var keys: Array = entry[1]
		for k in keys:
			var kw: String = k
			if low.find(kw) != -1:
				return entry[0]
	return ""

## Возвращает {роль: [пути...]} (пути отсортированы: *_lod0, *_lod1 ...).
static func scan(dir_path: String = MODEL_DIR) -> Dictionary:
	var found: Dictionary = {}
	_scan_dir(dir_path, found)
	for role in found:
		var arr: Array = found[role]
		arr.sort()
	return found

static func _scan_dir(dir_path: String, found: Dictionary) -> void:
	var da: DirAccess = DirAccess.open(dir_path)
	if da == null:
		return
	var seen: Dictionary = {}
	da.list_dir_begin()
	var fname: String = da.get_next()
	while fname != "":
		if da.current_is_dir():
			if not fname.begins_with("."):
				_scan_dir(dir_path + "/" + fname, found)
		else:
			var clean: String = fname
			for suf in [".import", ".remap"]:
				var sf: String = suf
				if clean.ends_with(sf):
					clean = clean.substr(0, clean.length() - sf.length())
			var ext: String = clean.get_extension().to_lower()
			if (ext == "glb" or ext == "gltf") and not seen.has(clean):
				seen[clean] = true
				var role: String = classify(clean.get_basename())
				if role == "":
					role = classify(dir_path.get_file())
				if role != "":
					if not found.has(role):
						found[role] = []
					var lst: Array = found[role]
					lst.append(dir_path + "/" + clean)
		fname = da.get_next()
	da.list_dir_end()

static func instance(path: String) -> Node3D:
	if ResourceLoader.exists(path):
		var res: Resource = load(path)
		if res is PackedScene:
			var n: Node = (res as PackedScene).instantiate()
			if n is Node3D:
				fix_vertex_colors(n)
				return n as Node3D
	# Запасной путь: импорт на лету (если редактор ещё не создал .import)
	var doc: GLTFDocument = GLTFDocument.new()
	var st: GLTFState = GLTFState.new()
	if doc.append_from_file(path, st) == OK:
		var n2: Node = doc.generate_scene(st)
		if n2 is Node3D:
			fix_vertex_colors(n2)
			return n2 as Node3D
	return null

## Модели с запечённым цветом в вершинах (COLOR_0): гарантируем, что материал его использует.
static func fix_vertex_colors(root: Node) -> void:
	var arr: Array = []
	collect_meshes(root, arr)
	for m in arr:
		var mi: MeshInstance3D = m
		if not (mi.mesh is ArrayMesh):
			continue
		var am: ArrayMesh = mi.mesh as ArrayMesh
		for si in am.get_surface_count():
			if (am.surface_get_format(si) & Mesh.ARRAY_FORMAT_COLOR) != 0:
				var base: Material = am.surface_get_material(si)
				var mat: StandardMaterial3D = null
				if base is StandardMaterial3D:
					mat = (base as StandardMaterial3D).duplicate() as StandardMaterial3D
				else:
					mat = StandardMaterial3D.new()
				mat.vertex_color_use_as_albedo = true
				mat.cull_mode = BaseMaterial3D.CULL_DISABLED
				mi.set_surface_override_material(si, mat)

static func collect_meshes(n: Node, out: Array) -> void:
	if n is MeshInstance3D:
		out.append(n)
	for c in n.get_children():
		collect_meshes(c, out)

static func first_mesh(root: Node) -> Mesh:
	var arr: Array = []
	collect_meshes(root, arr)
	if arr.is_empty():
		return null
	var mi: MeshInstance3D = arr[0]
	return mi.mesh

## Трансформ узла относительно предка (без учёта самого предка).
static func rel_xform(node: Node3D, ancestor: Node) -> Transform3D:
	var t: Transform3D = Transform3D.IDENTITY
	var n: Node = node
	while n != null and n != ancestor:
		if n is Node3D:
			t = (n as Node3D).transform * t
		n = n.get_parent()
	return t

static func mesh_aabb(root: Node3D) -> AABB:
	var arr: Array = []
	collect_meshes(root, arr)
	var res: AABB = AABB()
	var first: bool = true
	for m in arr:
		var mi: MeshInstance3D = m
		var box: AABB = rel_xform(mi, root) * mi.get_aabb()
		if first:
			res = box
			first = false
		else:
			res = res.merge(box)
	return res

## AABB модели в её локальных координатах: из заранее посчитанных метаданных
## (надёжно для скелетных мостов), иначе по мешам.
static func model_aabb(path: String, root: Node3D, meta: Dictionary) -> AABB:
	var key: String = path.get_file().get_basename()
	var ab: Dictionary = meta.get("aabb", {})
	if ab.has(key):
		var a: Array = ab[key]
		var mn: Array = a[0]
		var mx: Array = a[1]
		var p: Vector3 = Vector3(float(mn[0]), float(mn[1]), float(mn[2]))
		var q: Vector3 = Vector3(float(mx[0]), float(mx[1]), float(mx[2]))
		return AABB(p, q - p)
	return mesh_aabb(root)

## Масштабирует модель до target_height (или scale_override > 0), ставит
## основание на y = base_y, центрирует по X/Z. Возвращает масштаб.
static func fit(root: Node3D, ab: AABB, target_height: float, scale_override: float = 0.0, base_y: float = 0.0) -> float:
	var s: float = scale_override
	if s <= 0.0:
		var h: float = maxf(ab.size.y, 0.0001)
		s = target_height / h
	root.scale = Vector3(s, s, s)
	var c: Vector3 = ab.get_center()
	root.position = Vector3(-c.x * s, base_y - ab.position.y * s, -c.z * s)
	return s

## Точная коллизия: ConcavePolygonShape3D из всех мешей модели (трансформы
## запечены в вершины, поэтому у CollisionShape3D нет масштаба).
static func add_trimesh_body(holder: Node3D, model: Node3D) -> StaticBody3D:
	var body: StaticBody3D = StaticBody3D.new()
	body.name = "ModelCollision"
	holder.add_child(body)
	var arr: Array = []
	collect_meshes(model, arr)
	for m in arr:
		var mi: MeshInstance3D = m
		if mi.mesh == null:
			continue
		var xf: Transform3D = rel_xform(model, holder) * rel_xform(mi, model)
		var faces: PackedVector3Array = mi.mesh.get_faces()
		for i in faces.size():
			faces[i] = xf * faces[i]
		var shape: ConcavePolygonShape3D = ConcavePolygonShape3D.new()
		shape.set_faces(faces)
		var cs: CollisionShape3D = CollisionShape3D.new()
		cs.shape = shape
		body.add_child(cs)
	return body

static func add_cylinder_body(parent: Node3D, pos: Vector3, radius: float, height: float) -> StaticBody3D:
	var body: StaticBody3D = StaticBody3D.new()
	body.position = pos
	var cs: CollisionShape3D = CollisionShape3D.new()
	var cyl: CylinderShape3D = CylinderShape3D.new()
	cyl.radius = radius
	cyl.height = height
	cs.shape = cyl
	cs.position = Vector3(0.0, height * 0.5, 0.0)
	body.add_child(cs)
	parent.add_child(body)
	return body

static func find_anim_player(n: Node) -> AnimationPlayer:
	if n is AnimationPlayer:
		return n as AnimationPlayer
	for c in n.get_children():
		var r: AnimationPlayer = find_anim_player(c)
		if r != null:
			return r
	return null

## Выпуклая коллизия (для валунов): форма строится из меша, трансформы запечены в точки.
static func add_convex_body(holder: Node3D, model: Node3D) -> StaticBody3D:
	var body: StaticBody3D = StaticBody3D.new()
	body.name = "ModelCollision"
	holder.add_child(body)
	var arr: Array = []
	collect_meshes(model, arr)
	for m in arr:
		var mi: MeshInstance3D = m
		if mi.mesh == null:
			continue
		var xf: Transform3D = rel_xform(model, holder) * rel_xform(mi, model)
		var sh: ConvexPolygonShape3D = mi.mesh.create_convex_shape(true, false)
		if sh == null:
			continue
		var pts: PackedVector3Array = sh.points
		for i in pts.size():
			pts[i] = xf * pts[i]
		sh.points = pts
		var cs: CollisionShape3D = CollisionShape3D.new()
		cs.shape = sh
		body.add_child(cs)
	return body
