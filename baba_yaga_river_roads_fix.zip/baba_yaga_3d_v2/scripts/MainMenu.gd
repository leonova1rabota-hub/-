extends Node3D
## Стартовое меню: ночной лес в тумане, избушка Бабы Яги, готический заголовок.

const ModelLib = preload("res://scripts/ModelLib.gd")
const ModelData = preload("res://scripts/ModelData.gd")

const GAME_SCENE: String = "res://scenes/Main.tscn"
const NIGHT: Color = Color("0B0E14")

var cam: Camera3D = null
var angle: float = 0.6
var fade: ColorRect = null
var starting: bool = false
var title_label: Label = null

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_build_world()
	_build_ui()
	_start_music()

func _process(delta: float) -> void:
	angle += delta * 0.045
	if cam != null:
		var r: float = 17.0
		cam.position = Vector3(sin(angle) * r, 2.6 + sin(angle * 1.7) * 0.35, cos(angle) * r)
		cam.look_at(Vector3(0.0, 3.2, 0.0), Vector3.UP)

# ------------------------------------------------------------ 3D-фон
func _build_world() -> void:
	var env: Environment = Environment.new()
	var sky_ok: bool = false
	if ResourceLoader.exists("res://assets/sky_night.gdshader"):
		var sm: ShaderMaterial = ShaderMaterial.new()
		sm.shader = load("res://assets/sky_night.gdshader") as Shader
		if ResourceLoader.exists("res://assets/custom/sky_swamp.jpg"):
			sm.set_shader_parameter("swamp_tex", load("res://assets/custom/sky_swamp.jpg") as Texture2D)
		var sky: Sky = Sky.new()
		sky.sky_material = sm
		sky.radiance_size = Sky.RADIANCE_SIZE_64
		env.sky = sky
		env.background_mode = Environment.BG_SKY
		sky_ok = true
	if not sky_ok:
		env.background_mode = Environment.BG_COLOR
		env.background_color = NIGHT
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.13, 0.14, 0.30)
	env.ambient_light_energy = 1.0
	env.fog_enabled = true
	env.fog_light_color = Color(0.075, 0.08, 0.17)
	env.fog_density = 0.045
	if RenderingServer.get_current_rendering_method() == "forward_plus":
		env.volumetric_fog_enabled = true
		env.volumetric_fog_density = 0.04
		env.volumetric_fog_albedo = Color(0.35, 0.33, 0.6)
	env.glow_enabled = true
	env.glow_intensity = 1.0
	env.glow_bloom = 0.12
	env.glow_hdr_threshold = 0.85
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we: WorldEnvironment = WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var moon: DirectionalLight3D = DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-38.0, 150.0, 0.0)
	moon.light_color = Color(0.45, 0.5, 0.95)
	moon.light_energy = 0.55
	add_child(moon)

	var ground: MeshInstance3D = MeshInstance3D.new()
	var pm: PlaneMesh = PlaneMesh.new()
	pm.size = Vector2(240.0, 240.0)
	var gm: StandardMaterial3D = StandardMaterial3D.new()
	gm.albedo_color = Color(0.05, 0.07, 0.06)
	gm.roughness = 1.0
	pm.material = gm
	ground.mesh = pm
	add_child(ground)

	cam = Camera3D.new()
	cam.fov = 62.0
	cam.far = 300.0
	add_child(cam)
	cam.current = true

	var cat: Dictionary = ModelLib.scan()
	var meta: Dictionary = ModelData.META
	# изба
	var hp: Array = cat.get("house", [])
	if not hp.is_empty():
		var hpath: String = hp[0]
		var h: Node3D = ModelLib.instance(hpath)
		if h != null:
			var holder: Node3D = Node3D.new()
			add_child(holder)
			holder.add_child(h)
			var ab: AABB = ModelLib.model_aabb(hpath, h, meta)
			ModelLib.fit(h, ab, 6.0, 0.0, -0.22)
			var lamp: OmniLight3D = OmniLight3D.new()
			lamp.light_color = Color(1.0, 0.6, 0.25)
			lamp.light_energy = 2.2
			lamp.omni_range = 12.0
			lamp.position = Vector3(0.0, 2.0, 3.6)
			holder.add_child(lamp)
			var tw: Tween = create_tween().set_loops()
			for i in 4:
				tw.tween_property(lamp, "light_energy", randf_range(1.5, 2.6), randf_range(0.08, 0.25))
			var sw: Tween = create_tween().set_loops()
			sw.tween_property(holder, "rotation_degrees:z", 0.3, 3.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
			sw.tween_property(holder, "rotation_degrees:z", -0.3, 3.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	# мёртвые деревья по кольцу
	var tp: Array = cat.get("tree", [])
	if not tp.is_empty() and ResourceLoader.exists("res://assets/tree_sway.gdshader"):
		var tpath: String = tp[0]
		var t: Node3D = ModelLib.instance(tpath)
		if t != null:
			var msh: Mesh = ModelLib.first_mesh(t)
			t.queue_free()
			if msh != null:
				var dm: Mesh = msh.duplicate() as Mesh
				var tm: ShaderMaterial = ShaderMaterial.new()
				tm.shader = load("res://assets/tree_sway.gdshader") as Shader
				for s in dm.get_surface_count():
					dm.surface_set_material(s, tm)
				var rng: RandomNumberGenerator = RandomNumberGenerator.new()
				rng.seed = 42
				for i in 22:
					var a: float = rng.randf() * TAU
					var d: float = rng.randf_range(9.0, 46.0)
					var mi: MeshInstance3D = MeshInstance3D.new()
					mi.mesh = dm
					var hh: float = rng.randf_range(6.5, 10.5)
					mi.position = Vector3(sin(a) * d, 0.0, cos(a) * d)
					mi.rotation.y = rng.randf() * TAU
					mi.scale = Vector3(hh, hh, hh)
					mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
					add_child(mi)
	# туман у земли
	_add_fog_particles()

func _add_fog_particles() -> void:
	var p: GPUParticles3D = GPUParticles3D.new()
	p.amount = 40
	p.lifetime = 14.0
	p.preprocess = 14.0
	p.position = Vector3(0.0, 0.8, 0.0)
	p.visibility_aabb = AABB(Vector3(-40, -2, -40), Vector3(80, 8, 80))
	var pm: ParticleProcessMaterial = ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(30.0, 0.6, 30.0)
	pm.direction = Vector3(1.0, 0.0, 0.2)
	pm.spread = 25.0
	pm.initial_velocity_min = 0.3
	pm.initial_velocity_max = 0.8
	pm.gravity = Vector3.ZERO
	pm.scale_min = 0.8
	pm.scale_max = 1.6
	var g: Gradient = Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.3, 0.7, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, 0.5), Color(1, 1, 1, 0.5), Color(1, 1, 1, 0)])
	var gt: GradientTexture1D = GradientTexture1D.new()
	gt.gradient = g
	pm.color_ramp = gt
	p.process_material = pm
	var rg: Gradient = Gradient.new()
	rg.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
	rg.offsets = PackedFloat32Array([0.0, 1.0])
	var tex: GradientTexture2D = GradientTexture2D.new()
	tex.gradient = rg
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = 64
	tex.height = 64
	var q: QuadMesh = QuadMesh.new()
	q.size = Vector2(9.0, 4.0)
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = tex
	m.albedo_color = Color(0.22, 0.24, 0.42, 0.28)
	q.material = m
	p.draw_pass_1 = q
	add_child(p)

# ------------------------------------------------------------ интерфейс
func _build_ui() -> void:
	var layer: CanvasLayer = CanvasLayer.new()
	add_child(layer)
	if ResourceLoader.exists("res://assets/vignette.gdshader"):
		var v: ColorRect = ColorRect.new()
		v.set_anchors_preset(Control.PRESET_FULL_RECT)
		v.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var vm: ShaderMaterial = ShaderMaterial.new()
		vm.shader = load("res://assets/vignette.gdshader") as Shader
		vm.set_shader_parameter("strength", 1.0)
		v.material = vm
		layer.add_child(v)

	var root: Control = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_PASS
	layer.add_child(root)

	var box: VBoxContainer = VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_FULL_RECT)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 14)
	root.add_child(box)

	var top_space: Control = Control.new()
	top_space.size_flags_vertical = Control.SIZE_EXPAND_FILL
	top_space.custom_minimum_size = Vector2(0.0, 20.0)
	box.add_child(top_space)

	var font: SystemFont = SystemFont.new()
	font.font_names = PackedStringArray(["Old English Text MT", "UnifrakturCook", "UnifrakturMaguntia", "Blackadder ITC", "Luminari", "Papyrus", "Georgia", "Times New Roman", "serif"])
	font.font_weight = 700

	title_label = Label.new()
	title_label.text = "БАБА ЯГА"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_label.add_theme_font_override("font", font)
	title_label.add_theme_font_size_override("font_size", 104)
	title_label.add_theme_color_override("font_color", Color(0.86, 0.80, 0.66))
	title_label.add_theme_color_override("font_outline_color", Color(0.38, 0.03, 0.05))
	title_label.add_theme_constant_override("outline_size", 14)
	title_label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.85))
	title_label.add_theme_constant_override("shadow_offset_x", 4)
	title_label.add_theme_constant_override("shadow_offset_y", 6)
	box.add_child(title_label)

	var sub: Label = Label.new()
	sub.text = "Тропа тёмного леса"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_override("font", font)
	sub.add_theme_font_size_override("font_size", 34)
	sub.add_theme_color_override("font_color", Color(0.55, 0.62, 0.52))
	sub.add_theme_color_override("font_outline_color", Color(0.02, 0.02, 0.05))
	sub.add_theme_constant_override("outline_size", 6)
	box.add_child(sub)

	var mid_space: Control = Control.new()
	mid_space.size_flags_vertical = Control.SIZE_EXPAND_FILL
	mid_space.custom_minimum_size = Vector2(0.0, 30.0)
	box.add_child(mid_space)

	var row: HBoxContainer = HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_child(row)
	var btn: Button = Button.new()
	btn.text = "НАЧАТЬ ИГРУ"
	btn.custom_minimum_size = Vector2(380.0, 84.0)
	btn.focus_mode = Control.FOCUS_NONE
	btn.add_theme_font_override("font", font)
	btn.add_theme_font_size_override("font_size", 40)
	btn.add_theme_color_override("font_color", Color(0.9, 0.82, 0.62))
	btn.add_theme_color_override("font_hover_color", Color(1.0, 0.92, 0.7))
	btn.add_theme_color_override("font_pressed_color", Color(1.0, 0.6, 0.3))
	btn.add_theme_stylebox_override("normal", _btn_style(Color(0.11, 0.04, 0.05), Color(0.55, 0.4, 0.16), 3))
	btn.add_theme_stylebox_override("hover", _btn_style(Color(0.22, 0.06, 0.07), Color(0.9, 0.65, 0.25), 4))
	btn.add_theme_stylebox_override("pressed", _btn_style(Color(0.30, 0.08, 0.06), Color(1.0, 0.7, 0.3), 4))
	btn.pressed.connect(_on_start)
	row.add_child(btn)

	var hint: Label = Label.new()
	hint.text = "WASD / джойстик — ходьба   ·   Пробел / ПРЫЖОК — прыжок   ·   E — действие"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 20)
	hint.add_theme_color_override("font_color", Color(0.5, 0.52, 0.62))
	box.add_child(hint)
	var bottom: Control = Control.new()
	bottom.custom_minimum_size = Vector2(0.0, 36.0)
	box.add_child(bottom)

	# мерцание заголовка и «дыхание» кнопки
	var tt: Tween = create_tween().set_loops()
	tt.tween_property(title_label, "modulate", Color(1, 1, 1, 0.82), 1.7).set_trans(Tween.TRANS_SINE)
	tt.tween_property(title_label, "modulate", Color(1, 1, 1, 1.0), 1.1).set_trans(Tween.TRANS_SINE)
	btn.pivot_offset = btn.custom_minimum_size * 0.5
	var tb: Tween = create_tween().set_loops()
	tb.tween_property(btn, "scale", Vector2(1.03, 1.03), 1.4).set_trans(Tween.TRANS_SINE)
	tb.tween_property(btn, "scale", Vector2(1.0, 1.0), 1.4).set_trans(Tween.TRANS_SINE)

	fade = ColorRect.new()
	fade.color = Color(0, 0, 0, 1)
	fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(fade)
	var tf: Tween = create_tween()
	tf.tween_property(fade, "color:a", 0.0, 1.4)

func _btn_style(bg: Color, border: Color, bw: int) -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(bw)
	sb.set_corner_radius_all(6)
	sb.shadow_color = Color(border.r, border.g, border.b, 0.35)
	sb.shadow_size = 14
	sb.content_margin_left = 24.0
	sb.content_margin_right = 24.0
	return sb

func _start_music() -> void:
	var path: String = "res://assets/custom/creepy_ambient.mp3"
	if not ResourceLoader.exists(path):
		return
	var st: AudioStream = load(path) as AudioStream
	if st == null:
		return
	if st is AudioStreamMP3:
		(st as AudioStreamMP3).loop = true
	var pl: AudioStreamPlayer = AudioStreamPlayer.new()
	pl.stream = st
	pl.volume_db = -8.0
	add_child(pl)
	pl.play()

func _on_start() -> void:
	if starting:
		return
	starting = true
	GameManager.reset()
	var tw: Tween = create_tween()
	tw.tween_property(fade, "color:a", 1.0, 0.9)
	tw.tween_callback(func() -> void: get_tree().change_scene_to_file(GAME_SCENE))
