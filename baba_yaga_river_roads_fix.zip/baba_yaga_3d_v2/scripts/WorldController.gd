extends Node3D
## Логика всего мира: квесты, диалоги, мини-игры, звук, финальная кат-сцена.

const HAMMER: String = "Тяжёлый молот"
const WIND_DB: float = -8.0
const AMBIENT_DB: float = -18.0
const CAVE_DB: float = -6.0
const MUTED_DB: float = -60.0
const FADE_TIME: float = 2.0

const INGREDIENTS: Array[String] = ["Крыло ночной совы", "Цветок Хаоса", "Слёзы морской ведьмы", "Перо Феникса"]

const QUESTS: Array[String] = [
    "Принеси Крыло ночной совы (запад: сарай, овраг, башня на высоком холме)",
    "Добудь Цветок Хаоса (глубокая пещера в горе на востоке)",
    "Добудь Слёзы морской ведьмы (болотная низина на юге; флакон — в избушке)",
    "Добудь Перо Феникса (Огненный алтарь на холме на севере; факел — в избушке)"
]

const TASK_TEXTS: Array[String] = [
    "Явилась, наконец! Слушай, помощница: котёл стынет, а зелью Молодости нужны четыре чуда. Первое — Крыло ночной совы. Сова гнездится на башне, что стоит на высоком холме за оврагом, на западе. Топор найдёшь в сарае, ключ ищи в расщелине скал, а дальше смекай сама. Книга Рецептов тебе поможет.",
    "Второе чудо — Цветок Хаоса. Он окаменел в глубокой пещере в горе, на востоке. Алтарь заперт рунами: загадку рун ищи в Книге Рецептов и на скрижали в пещере. Да не перепутай кольца!",
    "Теперь Слёзы морской ведьмы. Живёт она в глухой болотной низине, на юге. Хрустальный флакон возьми с полки. Ведьма капризна: говори с ней по-доброму и с умом.",
    "Последнее — Перо Феникса. Огненный алтарь стоит на холме, на севере. Сухой факел у стены, огонь возьми у моего очага. Три жаровни зажги в нужном порядке — камень рядом подскажет."
]

const BREW_LINES: Array[String] = [
    "Ай да котёл! Булькает как надо. Подойди ко мне — назову второй ингредиент.",
    "Вот это аромат! Хаос в зелье — к удаче. Подойди ко мне за третьим заданием.",
    "Слёзы ведьмы! Зелье засветилось лунным светом. Остался последний ингредиент — подойди ко мне.",
    "Готово!"
]

@onready var player: CharacterBody3D = $Player
@onready var env_node: WorldEnvironment = $WorldEnvironment
@onready var sun: DirectionalLight3D = $Sun
@onready var ground: CSGBox3D = $Terrain/Ground
@onready var liquid: CSGCylinder3D = $Cauldron/Liquid
var liquid_y: float = 1.76
@onready var cauldron_light: OmniLight3D = $Cauldron/CauldronLight
@onready var yaga_model: Node3D = $YagaRoot/YagaModel
@onready var princess_model: Node3D = $YagaRoot/PrincessModel
@onready var yaga_flash: OmniLight3D = $YagaRoot/FlashLight
@onready var grate: Node3D = $Cave/Grate
@onready var tree_pivot: Node3D = $Ravine/DryTreePivot
@onready var trunk: CSGCylinder3D = $Ravine/DryTreePivot/Trunk
@onready var deck: CSGBox3D = $Ravine/BridgeDeck
@onready var chest_lid: Node3D = $Tower/Chest/LidPivot
@onready var fireflies: GPUParticles3D = $Player/Fireflies
@onready var wind_rig: Node3D = $WindRig
@onready var wind_player: AudioStreamPlayer = $Audio/WindPlayer
@onready var ambient_player: AudioStreamPlayer = $Audio/AmbientPlayer
@onready var cave_player: AudioStreamPlayer = $Audio/CavePlayer
@onready var cave_trigger: Area3D = $CaveAudioTrigger
@onready var pickup_player: AudioStreamPlayer = $Audio/Pickup
@onready var magic_player: AudioStreamPlayer = $Audio/Magic

var ia: Dictionary = {}
var taken: Dictionary = {}
var chopped: bool = false
var chest_opened: bool = false
var runes_solved: bool = false
var wall_broken: bool = false
var hammer_given: bool = false
var tears_taken: bool = false
var torch_lit: bool = false
var braziers_done: bool = false
var finale_done: bool = false
var lit_order: Array = []
var flash_rect: ColorRect
var t: float = 0.0
var in_cave: bool = false
var audio_tween: Tween

func _ready() -> void:
    for n in get_tree().get_nodes_in_group("interactable"):
        ia[str(n.get("object_id"))] = n
    GameManager.reset()
    GameManager.interacted.connect(_on_interacted)
    GameManager.minigame_finished.connect(_on_minigame_finished)
    GameManager.inventory_changed.connect(_on_inv_changed)
    GameManager.sfx_requested.connect(_play_sfx)
    _setup_audio()
    var cl: CanvasLayer = CanvasLayer.new()
    cl.layer = 30
    add_child(cl)
    flash_rect = ColorRect.new()
    flash_rect.color = Color(1.0, 1.0, 0.92, 0.0)
    flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cl.add_child(flash_rect)
    flash_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    refresh_world()
    GameManager.set_quest("Найди Книгу Рецептов в старой башне справа от избушки")
    await get_tree().process_frame
    _say("Баба Яга: Пойди туда, не знаю куда",
        "Ты — помощница старой Бабы Яги. Лес вокруг избушки околдован: мрачный, туманный, холодный, а вокруг долины высятся неприступные горы. Яга решила сварить Зелье Молодости, но для него нужны четыре чуда из четырёх уголков долины.\n\nНайди Книгу Рецептов в старой башне справа от избушки, а потом поговори с Ягой — она сидит в кресле у котла. Подбирать вещи можно в любой момент!\n\nУправление: джойстик слева — ходьба, свайп по правой половине экрана — обзор. На ПК: WASD — ходьба, ПКМ или стрелки — обзор, E — действие.")

func _setup_audio() -> void:
    # Зацикливаем mp3 (autoplay у плееров включён прямо в сцене).
    for p in [wind_player, ambient_player, cave_player]:
        var st: AudioStreamMP3 = (p as AudioStreamPlayer).stream as AudioStreamMP3
        if st != null:
            st.loop = true
    _ensure_cave_bus()
    cave_trigger.body_entered.connect(_on_cave_body_entered)
    cave_trigger.body_exited.connect(_on_cave_body_exited)

func _ensure_cave_bus() -> void:
    # Шина «Cave» с эхом (Delay) и гулкой реверберацией.
    if AudioServer.get_bus_index("Cave") >= 0:
        return
    AudioServer.add_bus()
    var idx: int = AudioServer.bus_count - 1
    AudioServer.set_bus_name(idx, "Cave")
    AudioServer.set_bus_send(idx, "Master")
    var echo: AudioEffectDelay = AudioEffectDelay.new()
    echo.dry = 0.8
    echo.tap1_active = true
    echo.tap1_delay_ms = 280.0
    echo.tap1_level_db = -6.0
    echo.tap2_active = true
    echo.tap2_delay_ms = 560.0
    echo.tap2_level_db = -10.0
    echo.feedback_active = true
    echo.feedback_delay_ms = 420.0
    echo.feedback_level_db = -12.0
    AudioServer.add_bus_effect(idx, echo)
    var rev: AudioEffectReverb = AudioEffectReverb.new()
    rev.room_size = 0.85
    rev.damping = 0.5
    rev.wet = 0.35
    rev.dry = 0.8
    AudioServer.add_bus_effect(idx, rev)

func _on_cave_body_entered(body: Node3D) -> void:
    if body == player:
        _set_cave_audio(true)

func _on_cave_body_exited(body: Node3D) -> void:
    if body == player:
        _set_cave_audio(false)

func _set_cave_audio(inside: bool) -> void:
    if inside == in_cave:
        return
    in_cave = inside
    if audio_tween != null and audio_tween.is_valid():
        audio_tween.kill()
    audio_tween = create_tween().set_parallel(true)
    if inside:
        if not cave_player.playing:
            cave_player.volume_db = MUTED_DB
            cave_player.play()
        audio_tween.tween_property(cave_player, "volume_db", CAVE_DB, FADE_TIME)
        audio_tween.tween_property(wind_player, "volume_db", MUTED_DB, FADE_TIME)
        audio_tween.tween_property(ambient_player, "volume_db", MUTED_DB, FADE_TIME)
    else:
        audio_tween.tween_property(cave_player, "volume_db", MUTED_DB, FADE_TIME)
        audio_tween.tween_property(wind_player, "volume_db", WIND_DB, FADE_TIME)
        audio_tween.tween_property(ambient_player, "volume_db", AMBIENT_DB, FADE_TIME)
        audio_tween.chain().tween_callback(cave_player.stop)

func _play_sfx(sfx_name: String) -> void:
    if sfx_name == "pickup":
        pickup_player.play()
    elif sfx_name == "magic":
        magic_player.play()

func _process(delta: float) -> void:
    t += delta
    wind_rig.global_position = player.global_position
    if not GameManager.cutscene:
        cauldron_light.light_energy = 2.0 + sin(t * 4.0) * 0.5
    liquid.position.y = liquid_y + sin(t * 3.0) * 0.02

# ------------------------------------------------------------ helpers
func _say(title: String, text: String, choices: Array = []) -> void:
    GameManager.show_dialogue(title, text, choices)

func _ch(txt: String, method: String, args: Array = []) -> Dictionary:
    var c: Callable = Callable(self, method)
    if args.size() > 0:
        c = c.bindv(args)
    return {"text": txt, "action": c}

func _tk(id: String) -> bool:
    return taken.has(id)

func _en(id: String, on: bool) -> void:
    if not ia.has(id):
        return
    var n = ia[id]  # без типа: удалённый узел нельзя присваивать типизированной переменной
    if not is_instance_valid(n):
        ia.erase(id)
        return
    n.call("set_enabled", on)

func _ia_node(id: String) -> Node:
    # Безопасный доступ к интерактивному узлу по id (null, если удалён).
    if ia.has(id) and is_instance_valid(ia[id]):
        return ia[id] as Node
    ia.erase(id)
    return null

func refresh_world() -> void:
    # Предметы-инструменты и книга доступны ВСЕГДА, независимо от сюжета.
    _en("book", not GameManager.book_found)
    _en("axe", not _tk("axe"))
    _en("stone_key", not _tk("stone_key"))
    _en("flask", not _tk("flask"))
    _en("torch_dry", not _tk("torch_dry"))
    _en("yaga", not finale_done)
    _en("cauldron", not finale_done)
    _en("fire", not torch_lit and not finale_done)
    _en("dry_tree", not chopped)
    _en("chest", not chest_opened)
    _en("rune_altar", not runes_solved)
    _en("chaos_flower", runes_solved and not _tk("chaos_flower"))
    _en("sea_witch", not tears_taken)
    _en("stone_hint", true)
    _en("cave_sign", true)
    _en("cave_wall", not wall_broken)
    for n in [1, 2, 3]:
        _en("brazier_%d" % n, not braziers_done and not lit_order.has(n))
    _en("phoenix_feather", braziers_done and not _tk("phoenix_feather"))

func _on_inv_changed() -> void:
    var s: int = GameManager.current_stage
    if s < 4 and GameManager.has_item(INGREDIENTS[s]):
        GameManager.set_quest("Брось «%s» в котёл Бабы Яги" % INGREDIENTS[s])

# ------------------------------------------------------------ interaction router
func _on_interacted(id: String, node: Node) -> void:
    if id.begins_with("brazier_"):
        _use_brazier(int(id.substr(8)), node)
        return
    match id:
        "book":
            _take_book(node)
        "yaga":
            _talk_yaga()
        "cauldron":
            _use_cauldron()
        "axe":
            _take_item("axe", "Ржавый топор", node, "Ты взяла ржавый топор. Им можно свалить сухое дерево.", true)
        "stone_key":
            _take_item("stone_key", "Старый ключ", node, "Под камнем лежал старый ключ с совиной головкой!", false)
        "dry_tree":
            _chop()
        "chest":
            _open_chest()
        "rune_altar":
            GameManager.minigame_requested.emit("runes")
        "chaos_flower":
            _take_item("chaos_flower", "Цветок Хаоса", node, "Цветок Хаоса в твоих руках — он тихо звенит.", true)
        "flask":
            _take_item("flask", "Пустой хрустальный флакон", node, "Ты взяла хрустальный флакон.", true)
        "sea_witch":
            _talk_witch()
        "torch_dry":
            _take_item("torch_dry", "Сухой факел", node, "Сухой факел. Теперь нужен огонь!", true)
        "fire":
            _light_torch()
        "cave_wall":
            _smash_wall(node)
        "cave_sign":
            GameManager.show_message("Каменные ступени уводят глубоко вниз. В темноте мерцают кристаллы...")
        "rune_hint":
            _say("Скрижаль в пещере", "Выбито на скрижали древними рунами:\n\n«Лишь тот сорвёт Цветок Хаоса, кто повторит вечный круг мира: Сначала выстави ту, что правит холодной ночью (Луна), затем ту стихию, что согреет в стужу и сожжёт спесь (Пламя), а венчает путь свет, что указывает дорогу путникам во тьме (Звезда).»")
        "stone_hint":
            _say("Надпись на камне", "Высечено на камне древними рунами:\n\n«Древний Феникс требует верного пламени: зажги ту жаровню, с которой восходит утро (I); затем пройди мимо срединной и затепли вечерний закат (III); и лишь в конце разожги полуденное сердце алтаря (II).»")
        "phoenix_feather":
            _take_item("phoenix_feather", "Перо Феникса", node, "Перо Феникса! Неси его скорее Яге.", true)

func _take_item(id: String, item: String, node: Node, msg: String, hide_node: bool) -> void:
    if _tk(id):
        return
    if not GameManager.add_item(item):
        return
    taken[id] = true
    if hide_node and is_instance_valid(node) and node is Node3D:
        (node as Node3D).visible = false
    GameManager.play_sfx("pickup")
    GameManager.show_message(msg)
    refresh_world()

func _take_book(node: Node) -> void:
    if _tk("book"):
        return
    taken["book"] = true
    if is_instance_valid(node) and node is Node3D:
        (node as Node3D).visible = false
    GameManager.set_book_found()
    GameManager.play_sfx("pickup")
    GameManager.set_quest("Вернись в избушку и поговори с Бабой Ягой")
    refresh_world()
    GameManager.show_book()

# ------------------------------------------------------------ Yaga & cauldron
func _talk_yaga() -> void:
    var s: int = GameManager.current_stage
    if s >= 4:
        return
    if s >= 1 and not hammer_given and not wall_broken:
        _give_hammer()
    if not GameManager.book_found:
        _say("Баба Яга", "Ты чего с пустыми руками, лентяйка?! Без Книги Рецептов зелье не сваришь. Сбегай в старую башню справа от избушки — книга лежит там на пьедестале.")
        return
    if not GameManager.task_active:
        _say("Баба Яга", TASK_TEXTS[s], [_ch("Иду, бабушка!", "_start_task")])
    else:
        _say("Баба Яга", "Что стоишь, помощница? Время идёт!\n\n" + QUESTS[s] + "\n\nЕсли забыла подсказки — загляни в Книгу Рецептов.")

func _start_task() -> void:
    GameManager.task_active = true
    GameManager.set_quest(QUESTS[GameManager.current_stage])
    refresh_world()

func _use_cauldron() -> void:
    var s: int = GameManager.current_stage
    if s >= 4:
        return
    if GameManager.has_item(INGREDIENTS[s]):
        GameManager.minigame_requested.emit("cauldron")
    else:
        GameManager.show_message("Котёл кипит впустую. Сейчас нужно: «%s»." % INGREDIENTS[s])

func _on_minigame_finished(type: String, success: bool) -> void:
    if type == "cauldron":
        if success:
            _brew_done()
        else:
            GameManager.show_message("Зелье не сварено. Яга ворчит: «Растяпа!»")
    elif type == "runes":
        if success and not runes_solved:
            _runes_done()

func _tint_cauldron(i: int) -> void:
    var cols: Array = [Color(0.25, 0.85, 0.4), Color(0.6, 0.4, 0.95), Color(0.3, 0.85, 0.95), Color(1.0, 0.8, 0.25)]
    var c: Color = cols[i % cols.size()]
    var m: StandardMaterial3D = liquid.material as StandardMaterial3D
    var tw: Tween = create_tween().set_parallel(true)
    tw.tween_property(m, "albedo_color", c, 1.5)
    tw.tween_property(m, "emission", c, 1.5)
    tw.tween_property(cauldron_light, "light_color", c, 1.5)

func _brew_done() -> void:
    var s: int = GameManager.current_stage
    if s >= 4 or not GameManager.has_item(INGREDIENTS[s]):
        return
    GameManager.remove_item(INGREDIENTS[s])
    GameManager.current_stage = s + 1
    GameManager.task_active = false
    GameManager.play_sfx("magic")
    _tint_cauldron(s)
    if s == 0:
        # Награда за первое зелье: Яга выдаёт молот для завала в пещере.
        _give_hammer()
    refresh_world()
    if s + 1 >= 4:
        start_finale()
    else:
        GameManager.set_quest("Поговори с Бабой Ягой (сварено %d из 4)" % (s + 1))
        var extra: String = "\n\nИ держи тяжёлый молот — в пещере на востоке завал, им разобьёшь потрескавшуюся стену." if s == 0 else ""
        _say("Баба Яга", BREW_LINES[s] + extra)

# ------------------------------------------------------------ stage 1
func _chop() -> void:
    if not GameManager.has_item("Ржавый топор"):
        GameManager.show_message("Голыми руками дерево не свалить. Нужен топор из сарая.")
        return
    chopped = true
    GameManager.remove_item("Ржавый топор")
    _en("dry_tree", false)
    trunk.use_collision = false
    var tw: Tween = create_tween()
    tw.tween_property(tree_pivot, "rotation_degrees:z", 90.0, 1.6).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    tw.tween_callback(_bridge_ready)
    GameManager.show_message("Тр-р-рах! Дерево падает через овраг...")

func _bridge_ready() -> void:
    deck.visible = true
    deck.use_collision = true
    GameManager.show_message("Мост готов! Можно идти к башне на высоком холме.")

func _open_chest() -> void:
    if not GameManager.has_item("Старый ключ"):
        GameManager.show_message("Сундук заперт. Ключ спрятан в расщелине скал на юго-западе.")
        return
    GameManager.remove_item("Старый ключ")
    if not GameManager.add_item("Крыло ночной совы"):
        GameManager.add_item("Старый ключ")
        return
    chest_opened = true
    _en("chest", false)
    GameManager.play_sfx("pickup")
    create_tween().tween_property(chest_lid, "rotation_degrees:x", -105.0, 0.8)
    GameManager.show_message("Щёлк! Внутри — Крыло ночной совы.")
    refresh_world()

# ------------------------------------------------------------ stage 2
func _runes_done() -> void:
    if runes_solved:
        return
    runes_solved = true
    GameManager.play_sfx("magic")
    if is_instance_valid(grate):
        for c in grate.get_children():
            if c is CSGShape3D:
                (c as CSGShape3D).use_collision = false
        create_tween().tween_property(grate, "position:y", -14.6, 2.5)
    GameManager.show_message("Кольца встали на места — решётка опускается!")
    refresh_world()

func _smash_wall(node: Node) -> void:
    if wall_broken or not is_instance_valid(node):
        return
    if not GameManager.has_item(HAMMER):
        GameManager.show_dialogue("Завал из камней!", "Потрескавшаяся стена перегораживает ход вглубь пещеры. Нужно сначала сварить первое зелье — Баба Яга даст тяжёлый молот, чтобы разбить эту стену.")
        return
    GameManager.remove_item(HAMMER)
    wall_broken = true
    node.call("set_enabled", false)
    var body: Node3D = node as Node3D
    var shape: CollisionShape3D = body.get_node_or_null("Shape") as CollisionShape3D
    if shape != null:
        shape.set_deferred("disabled", true)
    GameManager.play_sfx("magic")
    GameManager.show_message("Бам! Стена рассыпается на камни — путь в пещеру свободен!")
    var tw: Tween = create_tween()
    tw.tween_property(body, "position:y", body.position.y - 7.0, 1.2).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    # Узел не удаляем (на него могут ссылаться фокус/словарь) — просто прячем.
    tw.tween_callback(_hide_node.bind(body))
    refresh_world()

func _hide_node(n: Node3D) -> void:
    if is_instance_valid(n):
        n.visible = false

func _give_hammer() -> void:
    if hammer_given or wall_broken:
        return
    if GameManager.add_item(HAMMER):
        hammer_given = true

# ------------------------------------------------------------ stage 3
func _talk_witch() -> void:
    if not GameManager.has_item("Пустой хрустальный флакон"):
        _say("Морская ведьма", "Хм... Чем ты собралась ловить мои слёзы, смертная? Без хрустального флакона и разговора нет. Он стоит на полке в избушке у Яги.")
        return
    _witch_step(1)

func _witch_step(step: int) -> void:
    if step == 1:
        _say("Морская ведьма", "Кто посмел потревожить мою топь?! Уходи, смертная... Слёзы мои не продаются, и жалости у меня не выпросишь.", [
            _ch("Отдай слёзы по-хорошему, или Яга тебе устроит!", "_witch_wrong", ["Ведьма шипит, и вокруг тебя поднимается ледяной туман: «Угрозами со мной не говорят!»"]),
            _ch("Ты так одинока и печальна... Что тебя гнетёт, хозяйка топи?", "_witch_step", [2]),
            _ch("Я заплачу за слёзы медную монету.", "_witch_wrong", ["«Медью?! Мне?!» — хохочет ведьма и хлещет хвостом по воде. Брызги бьют тебя в лицо."])
        ])
    elif step == 2:
        _say("Морская ведьма", "Ведьма отворачивается, и вода у трона тихо дрожит: «Была у меня жемчужина — Лунная Слеза, дар матери-океана. Шторм унёс её, и с тех пор я не умею плакать по-настоящему.»", [
            _ch("Подумаешь, камешек. Купи себе другой.", "_witch_wrong", ["«Камешек?!» — взвыла ведьма. Болото вскипело, и тебе пришлось отступить."]),
            _ch("Хочешь, я поищу тебе новую жемчужину в лавке?", "_witch_wrong", ["«Лавочную безделушку?» — холодно спросила ведьма. — «Ты ничего не поняла.»"]),
            _ch("Жемчужина хранит песню прибоя. Наверное, без неё в топи слишком тихо.", "_witch_step", [3])
        ])
    elif step == 3:
        _say("Морская ведьма", "Ведьма поднимает глаза, полные влаги: «Ты слышала... песню прибоя? Никто не говорил со мной так со времён шторма. Чего ты хочешь от меня, добрая душа?»", [
            _ch("Одну слезу — во флакон. Яга сварит зелье, а память о жемчужине останется с тобой.", "_witch_done"),
            _ch("Выжимай слёзы скорее, у меня дела!", "_witch_wrong", ["Ведьма вспыхивает: «Дела у неё!» — и слёзы высыхают на глазах."]),
            _ch("Ладно, не буду тебя тревожить.", "_witch_wrong", ["Ведьма вздыхает: «Вот и уходи...» Придётся начать разговор заново."])
        ])

func _witch_wrong(reaction: String) -> void:
    _say("Морская ведьма", reaction, [_ch("Начать разговор заново", "_witch_step", [1])])

func _witch_done() -> void:
    GameManager.remove_item("Пустой хрустальный флакон")
    GameManager.add_item("Слёзы морской ведьмы")
    tears_taken = true
    GameManager.play_sfx("magic")
    refresh_world()
    _say("Морская ведьма", "Ведьма прикрывает глаза, и по её щеке катится слеза — крупная, как жемчужина. Она падает во флакон и светится лунным светом.\n\n«Передай Яге: пусть сварит доброе зелье.»")

# ------------------------------------------------------------ stage 4
func _light_torch() -> void:
    if not GameManager.has_item("Сухой факел"):
        GameManager.show_message("Огонь жарко пылает. Нужен сухой факел — он стоит у стены избушки.")
        return
    GameManager.remove_item("Сухой факел")
    GameManager.add_item("Горящий факел")
    torch_lit = true
    GameManager.play_sfx("magic")
    refresh_world()
    GameManager.set_quest("Неси горящий факел на север, к Огненному алтарю на холме, и зажги три жаровни")
    GameManager.show_message("Факел вспыхнул!")

func _set_brazier(b: Node, lit: bool) -> void:
    var fl: Node3D = b.get_node_or_null("Flame") as Node3D
    var lg: Node3D = b.get_node_or_null("Light") as Node3D
    if fl != null:
        fl.visible = lit
    if lg != null:
        lg.visible = lit

func _use_brazier(n: int, node: Node) -> void:
    if not GameManager.has_item("Горящий факел"):
        GameManager.show_message("Жаровня холодна. Нужен огонь — зажги факел от очага Яги.")
        return
    if not is_instance_valid(node) or lit_order.has(n):
        return
    lit_order.append(n)
    _set_brazier(node, true)
    node.call("set_enabled", false)
    if lit_order.size() < 3:
        GameManager.show_message("Жаровня вспыхнула!")
        return
    if lit_order == [1, 3, 2]:
        braziers_done = true
        GameManager.play_sfx("magic")
        var feather: Node = _ia_node("phoenix_feather")
        if is_instance_valid(feather):
            (feather as Node3D).visible = true
        refresh_world()
        GameManager.show_message("Алтарь вспыхнул золотом — появилось Перо Феникса!")
    else:
        for k in [1, 2, 3]:
            var b: Node = _ia_node("brazier_%d" % k)
            if is_instance_valid(b):
                _set_brazier(b, false)
        lit_order.clear()
        refresh_world()
        GameManager.show_message("Огни погасли — порядок неверен. Перечитай камень.")

# ------------------------------------------------------------ finale
func _face_yaga() -> void:
    var target: Vector3 = ($YagaRoot as Node3D).global_position
    var d: Vector3 = target - player.global_position
    var yaw: float = atan2(-d.x, -d.z)
    var final_yaw: float = player.rotation.y + wrapf(yaw - player.rotation.y, -PI, PI)
    var tw: Tween = create_tween().set_parallel(true)
    tw.tween_property(player, "rotation:y", final_yaw, 1.2)
    tw.tween_property(player.get_node("Head"), "rotation:x", 0.1, 1.2)
    player.set("pitch", 0.1)

func _swap_models() -> void:
    yaga_model.visible = false
    princess_model.visible = true

func _set_foliage(col: Color, sm: ShaderMaterial) -> void:
    sm.set_shader_parameter("albedo", col)

func start_finale() -> void:
    GameManager.cutscene = true
    finale_done = true
    GameManager.move_vec = Vector2.ZERO
    GameManager.set_quest("Зелье Молодости готово!")
    _face_yaga()
    create_tween().tween_property(cauldron_light, "light_energy", 7.0, 1.4)
    await get_tree().create_timer(1.8).timeout
    GameManager.show_message("Баба Яга выпивает зелье...")
    await get_tree().create_timer(2.0).timeout

    GameManager.play_sfx("magic")
    var tf: Tween = create_tween()
    tf.tween_property(flash_rect, "color:a", 1.0, 0.7)
    tf.tween_callback(_swap_models)
    tf.tween_property(flash_rect, "color:a", 0.0, 1.6)
    var tl: Tween = create_tween()
    tl.tween_property(yaga_flash, "light_energy", 14.0, 0.7)
    tl.tween_property(yaga_flash, "light_energy", 0.0, 1.6)

    var env: Environment = env_node.environment
    var tw: Tween = create_tween().set_parallel(true)
    tw.tween_property(env, "background_color", Color(0.529, 0.808, 0.922), 3.0)
    tw.tween_property(env, "ambient_light_color", Color(1.0, 0.9, 0.6), 3.0)
    tw.tween_property(env, "ambient_light_energy", 1.4, 3.0)
    tw.tween_property(env, "fog_light_color", Color(0.75, 0.9, 0.97), 3.0)
    tw.tween_property(env, "fog_density", 0.002, 3.0)
    get_tree().call_group("world_finale", "on_finale", 3.0)
    tw.tween_property(sun, "light_energy", 1.2, 3.0)
    tw.tween_property(sun, "light_color", Color(1.0, 0.88, 0.55), 3.0)
    var gm: StandardMaterial3D = ground.material as StandardMaterial3D
    tw.tween_property(gm, "albedo_color", Color(0.36, 0.68, 0.28), 3.0)
    var mats: Array = []
    for n in get_tree().get_nodes_in_group("forest_foliage"):
        var m: Material = (n as CSGShape3D).material
        if m != null and not mats.has(m):
            mats.append(m)
    var targets: Array = [Color(0.18, 0.75, 0.35), Color(1.0, 0.62, 0.78), Color(0.3, 0.7, 0.3)]
    for i in range(mats.size()):
        var c: Color = targets[i % targets.size()]
        if mats[i] is ShaderMaterial:
            var sm: ShaderMaterial = mats[i] as ShaderMaterial
            var from_c: Color = sm.get_shader_parameter("albedo")
            tw.tween_method(_set_foliage.bind(sm), from_c, c, 3.0)
        elif mats[i] is StandardMaterial3D:
            tw.tween_property(mats[i], "albedo_color", c, 3.0)

    await get_tree().create_timer(3.4).timeout
    fireflies.emitting = true
    await get_tree().create_timer(3.0).timeout
    GameManager.cutscene = false
    _say("Зелье Молодости!", "Баба Яга выпила зелье — и перед тобой стоит прекрасная Принцесса, которую злые чары когда-то превратили в старуху!\n\nВместе с проклятием рассеялся мрак: лес зазеленел и расцвёл, туман ушёл, а в воздухе закружились золотые светлячки.\n\nСпасибо тебе, верная помощница! Ты пошла туда, не знаю куда, и принесла то, не знаю что.", [_ch("Сыграть снова", "_restart")])

func _restart() -> void:
    GameManager.reset()
    get_tree().reload_current_scene()
