extends OmniLight3D
## Тёплое мерцание света жаровни (энергия ~1.8, радиус 6).

@export var base_energy: float = 1.8
var t: float = 0.0
var phase: float = 0.0

func _ready() -> void:
	phase = randf() * 10.0
	light_energy = base_energy

func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	t += delta
	var k: float = 0.88 + 0.12 * sin((t + phase) * 17.0) * sin((t + phase) * 9.3 + 1.7) + randf_range(-0.07, 0.07)
	light_energy = base_energy * k
