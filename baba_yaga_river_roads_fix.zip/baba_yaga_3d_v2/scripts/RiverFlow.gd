extends MeshInstance3D
## Река в бывшей расщелине: течение (анимация нормалей) и возврат на берег при падении.

const HALF_WIDTH: float = 3.4
const RIVER_X: float = -40.0
var mat: StandardMaterial3D = null
var flow: float = 0.0

func _ready() -> void:
	mat = material_override as StandardMaterial3D
	if mat != null:
		var noise: FastNoiseLite = FastNoiseLite.new()
		noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
		noise.frequency = 0.03
		var nt: NoiseTexture2D = NoiseTexture2D.new()
		nt.width = 256
		nt.height = 256
		nt.seamless = true
		nt.as_normal_map = true
		nt.bump_strength = 3.0
		nt.noise = noise
		mat.normal_texture = nt

func _process(delta: float) -> void:
	if mat == null:
		return
	flow += delta * 0.035
	mat.uv1_offset = Vector3(flow * 0.15, flow * 4.0, 0.0)

func _physics_process(_delta: float) -> void:
	var pl: CharacterBody3D = get_parent().get_parent().get_node_or_null("Player") as CharacterBody3D
	if pl == null:
		return
	var gp: Vector3 = pl.global_position
	if gp.y < -1.8 and absf(gp.x - RIVER_X) < HALF_WIDTH and gp.y > -9.0:
		var sp: Vector3 = pl.get("safe_pos")
		pl.global_position = sp
		pl.velocity = Vector3.ZERO
		GameManager.show_message("Течение вынесло тебя на берег.")
