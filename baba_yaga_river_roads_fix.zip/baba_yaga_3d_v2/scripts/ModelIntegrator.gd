extends Node3D
## Автоподстановка 3D-моделей из res://assets/custom/models/ в мир игры.
## Роли определяются по имени файла (см. ModelLib.ROLE_KEYS). Если модели нет —
## остаётся процедурный объект, игра работает как раньше.

const ModelLib = preload("res://scripts/ModelLib.gd")
const ModelData = preload("res://scripts/ModelData.gd")

const TREE_SHADER: String = "res://assets/tree_sway.gdshader"
const TREE_CELL: float = 32.0
const TREE_LOD_DIST: float = 50.0
const TREE_FAR_DIST: float = 170.0

const HOUSE_POS: Vector3 = Vector3(2.0, 0.0, 46.0)
const HOUSE_YAW_DEG: float = 180.0
const HOUSE_HEIGHT: float = 6.0
const HOUSE_SINK: float = -0.22      # цокольная «дёрновая» часть модели уходит в землю

const CAULDRON_SCALE: float = 0.0125  # модель котла в сантиметрах
const WITCH_HEIGHT: float = 1.7
const CANDLE_HEIGHT: float = 1.7

var catalog: Dictionary = {}
var meta: Dictionary = {}
var tree_mat: ShaderMaterial = null
var flame_tex: GradientTexture2D = null

func _ready() -> void:
	add_to_group("world_finale")
	meta = ModelData.META
	catalog = ModelLib.scan()
	print("[ModelIntegrator] найдено ролей: ", catalog.keys())
	flame_tex = _make_glow_tex()
	_build_trees()
	_build_rocks()
	_build_axe()
	_build_house()
	_build_witch()
	_build_cauldron()
	_build_altar()
	_build_candles()

# ------------------------------------------------------------------ helpers
func _make_glow_tex() -> GradientTexture2D:
	var g: Gradient = Gradient.new()
	g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
	g.offsets = PackedFloat32Array([0.0, 1.0])
	var t: GradientTexture2D = GradientTexture2D.new()
	t.gradient = g
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.5)
	t.fill_to = Vector2(1.0, 0.5)
	t.width = 64
	t.height = 64
	return t

func _glow_material(col: Color) -> StandardMaterial3D:
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = flame_tex
	m.albedo_color = col
	m.disable_receive_shadows = true
	return m

func _hide_csg(n: Node) -> void:
	if n == null:
		return
	if n is CSGShape3D:
		var c: CSGShape3D = n as CSGShape3D
		c.visible = false
		c.use_collision = false
	elif n is Node3D:
		(n as Node3D).visible = false

func _flicker(light: OmniLight3D, base: float) -> void:
	var tw: Tween = create_tween().set_loops()
	for i in 4:
		tw.tween_property(light, "light_energy", base * randf_range(0.7, 1.2), randf_range(0.08, 0.22))

func _add_flame(parent: Node3D, pos: Vector3, size: float) -> void:
	var q: QuadMesh = QuadMesh.new()
	q.size = Vector2(size, size * 1.6)
	q.material = _glow_material(Color(2.6, 1.3, 0.45, 1.0))
	var mi: MeshInstance3D = MeshInstance3D.new()
	mi.mesh = q
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	var tw: Tween = create_tween().set_loops()
	tw.tween_property(mi, "scale", Vector3(0.85, 1.15, 1.0), randf_range(0.12, 0.3))
	tw.tween_property(mi, "scale", Vector3(1.1, 0.9, 1.0), randf_range(0.12, 0.3))

func _sway(node: Node3D, deg: float, period: float) -> void:
	var tz: Tween = create_tween().set_loops()
	tz.tween_property(node, "rotation_degrees:z", deg, period).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tz.tween_property(node, "rotation_degrees:z", -deg, period).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	var tx: Tween = create_tween().set_loops()
	tx.tween_property(node, "rotation_degrees:x", deg * 0.6, period * 1.37).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tx.tween_property(node, "rotation_degrees:x", -deg * 0.6, period * 1.37).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	# «дыхание» избы: лёгкое растяжение по высоте
	var tb: Tween = create_tween().set_loops()
	tb.tween_property(node, "scale", Vector3(1.0, 1.006, 1.0), period * 0.8).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tb.tween_property(node, "scale", Vector3(1.0, 0.996, 1.0), period * 0.8).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

# ------------------------------------------------------------------ trees
func _build_trees() -> void:
	var paths: Array = catalog.get("tree", [])
	if paths.is_empty():
		return
	var meshes: Array = []
	if ResourceLoader.exists(TREE_SHADER):
		tree_mat = ShaderMaterial.new()
		tree_mat.shader = load(TREE_SHADER) as Shader
	for p in paths:
		var path: String = p
		var inst: Node3D = ModelLib.instance(path)
		if inst == null:
			continue
		var msh: Mesh = ModelLib.first_mesh(inst)
		if msh != null:
			var dup: Mesh = msh.duplicate() as Mesh
			if tree_mat != null:
				for s in dup.get_surface_count():
					dup.surface_set_material(s, tree_mat)
			meshes.append(dup)
		inst.queue_free()
	if meshes.is_empty():
		return
	var spots: Array = ModelData.TREE_SPOTS
	var cells: Dictionary = {}
	for i in spots.size():
		var sp: Array = spots[i]
		var key: Vector2i = Vector2i(floori(float(sp[0]) / TREE_CELL), floori(float(sp[2]) / TREE_CELL))
		if not cells.has(key):
			cells[key] = []
		var lst: Array = cells[key]
		lst.append(i)
	var root: Node3D = Node3D.new()
	root.name = "ModelTrees"
	add_child(root)
	var trunk_r: float = float(meta.get("dead_tree", {}).get("trunk_r", 0.065))
	var colliders: StaticBody3D = StaticBody3D.new()
	colliders.name = "TreeColliders"
	root.add_child(colliders)
	for key in cells:
		var arr: Array = cells[key]
		var k2: Vector2i = key
		var center: Vector3 = Vector3((k2.x + 0.5) * TREE_CELL, 0.0, (k2.y + 0.5) * TREE_CELL)
		for lod in meshes.size():
			var mm: MultiMesh = MultiMesh.new()
			mm.transform_format = MultiMesh.TRANSFORM_3D
			mm.mesh = meshes[lod]
			mm.instance_count = arr.size()
			for j in arr.size():
				var sp2: Array = spots[arr[j]]
				var h: float = float(sp2[4])
				var b: Basis = Basis(Vector3.UP, float(sp2[3])).scaled(Vector3(h, h, h))
				mm.set_instance_transform(j, Transform3D(b, Vector3(float(sp2[0]) - center.x, float(sp2[1]), float(sp2[2]) - center.z)))
			var mmi: MultiMeshInstance3D = MultiMeshInstance3D.new()
			mmi.multimesh = mm
			mmi.position = center
			mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			if meshes.size() > 1:
				if lod == 0:
					mmi.visibility_range_end = TREE_LOD_DIST
				else:
					mmi.visibility_range_begin = TREE_LOD_DIST
					mmi.visibility_range_end = TREE_FAR_DIST
			else:
				mmi.visibility_range_end = TREE_FAR_DIST
			root.add_child(mmi)
		for idx in arr:
			var sp3: Array = spots[idx]
			var hh: float = float(sp3[4])
			var cs: CollisionShape3D = CollisionShape3D.new()
			var cyl: CylinderShape3D = CylinderShape3D.new()
			cyl.radius = maxf(trunk_r * hh, 0.25)
			cyl.height = minf(hh * 0.6, 4.5)
			cs.shape = cyl
			cs.position = Vector3(float(sp3[0]), float(sp3[1]) + cyl.height * 0.5, float(sp3[2]))
			colliders.add_child(cs)

# ------------------------------------------------------------------ rocks (мшистые валуны вместо угловатых блоков)
func _build_rocks() -> void:
	var paths: Array = catalog.get("rock", [])
	var forest: Node = get_parent().get_node_or_null("Forest")
	if paths.is_empty() or forest == null:
		return
	var root: Node3D = Node3D.new()
	root.name = "ModelRocks"
	add_child(root)
	var k: int = 0
	for c in forest.get_children():
		var nm: String = String(c.name)
		if not (c is CSGBox3D) or not nm.begins_with("Rk"):
			continue
		var src: CSGBox3D = c as CSGBox3D
		var path: String = paths[k % paths.size()]
		k += 1
		var inst: Node3D = ModelLib.instance(path)
		if inst == null:
			continue
		var holder: Node3D = Node3D.new()
		holder.position = Vector3(src.position.x, 0.0, src.position.z)
		holder.rotation.y = src.rotation.y
		root.add_child(holder)
		holder.add_child(inst)
		var ab: AABB = ModelLib.model_aabb(path, inst, meta)
		var w: float = maxf(src.size.x, src.size.z) * 1.1
		var s: float = w / maxf(maxf(ab.size.x, ab.size.z), 0.0001)
		ModelLib.fit(inst, ab, 0.0, s, src.position.y - src.size.y * 0.5 - 0.05)
		ModelLib.add_convex_body(holder, inst)
		_hide_csg(src)
		var moss: Node = forest.get_node_or_null("Rm" + nm.substr(2))
		_hide_csg(moss)

# ------------------------------------------------------------------ axe (топор, воткнутый в пень)
func _build_axe() -> void:
	var paths: Array = catalog.get("axe", [])
	var axe: Node3D = get_parent().get_node_or_null("Shed/Axe") as Node3D
	if paths.is_empty() or axe == null:
		return
	var path: String = paths[0]
	var inst: Node3D = ModelLib.instance(path)
	if inst == null:
		return
	_hide_csg(axe.get_node_or_null("Handle"))
	_hide_csg(axe.get_node_or_null("Blade"))
	axe.add_child(inst)
	# Модель: рукоять вдоль +Y, режущая кромка на +X. Поворот на -108° вокруг Z:
	# кромка смотрит вниз (с наклоном 18°), рукоять приподнята на 18° над горизонталью.
	var ed: Array = meta.get("axe", {}).get("edge", [1.36, 3.154, 0.0])
	var edge: Vector3 = Vector3(float(ed[0]), float(ed[1]), float(ed[2]))
	var s: float = 0.157
	var basis: Basis = Basis(Vector3.UP, deg_to_rad(20.0)) * Basis(Vector3(0.0, 0.0, 1.0), deg_to_rad(-108.0)) * Basis.from_scale(Vector3(s, s, s))
	# верх пня в локальных координатах узла топора: y = -0.3; лезвие врублено на 12 см вглубь
	var target: Vector3 = Vector3(0.0, -0.3 - 0.12, 0.0)
	inst.transform = Transform3D(basis, target - basis * edge)

# ------------------------------------------------------------------ house
func _build_house() -> void:
	var paths: Array = catalog.get("house", [])
	if paths.is_empty():
		return
	var path: String = paths[0]
	var inst: Node3D = ModelLib.instance(path)
	if inst == null:
		return
	var holder: Node3D = Node3D.new()
	holder.name = "WitchCottage"
	holder.position = HOUSE_POS
	holder.rotation_degrees = Vector3(0.0, HOUSE_YAW_DEG, 0.0)
	add_child(holder)
	var pivot: Node3D = Node3D.new()
	pivot.name = "SwayPivot"
	holder.add_child(pivot)
	pivot.add_child(inst)
	var ab: AABB = ModelLib.model_aabb(path, inst, meta)
	ModelLib.fit(inst, ab, HOUSE_HEIGHT, 0.0, HOUSE_SINK)
	ModelLib.add_trimesh_body(holder, inst)    # коллизия не качается вместе с визуалом
	var lamp: OmniLight3D = OmniLight3D.new()
	lamp.light_color = Color(1.0, 0.62, 0.28)
	lamp.light_energy = 1.4
	lamp.omni_range = 9.0
	lamp.position = Vector3(0.0, 2.2, 3.4)
	holder.add_child(lamp)
	_flicker(lamp, 1.4)
	_sway(pivot, 0.28, 3.2)

# ------------------------------------------------------------------ witch (Баба Яга)
func _build_witch() -> void:
	var paths: Array = catalog.get("witch", [])
	var yaga: Node3D = get_parent().get_node_or_null("YagaRoot/YagaModel") as Node3D
	if paths.is_empty() or yaga == null:
		return
	var path: String = paths[0]
	var inst: Node3D = ModelLib.instance(path)
	if inst == null:
		return
	for c in yaga.get_children():
		if c is CSGShape3D:
			(c as CSGShape3D).visible = false
			(c as CSGShape3D).use_collision = false
	var chair: Node = get_parent().get_node_or_null("YagaRoot/Chair")
	if chair != null:
		for c2 in chair.get_children():
			_hide_csg(c2)
	yaga.add_child(inst)
	var ab: AABB = ModelLib.model_aabb(path, inst, meta)
	ModelLib.fit(inst, ab, WITCH_HEIGHT, 0.0, 0.02)
	var ap: AnimationPlayer = ModelLib.find_anim_player(inst)
	if ap != null:
		var names: PackedStringArray = ap.get_animation_list()
		if names.size() > 0:
			var anim: Animation = ap.get_animation(names[0])
			if anim != null:
				anim.loop_mode = Animation.LOOP_LINEAR
			ap.play(names[0])

# ------------------------------------------------------------------ cauldron
func _build_cauldron() -> void:
	var paths: Array = catalog.get("cauldron", [])
	var cauldron: Node3D = get_parent().get_node_or_null("Cauldron") as Node3D
	if paths.is_empty() or cauldron == null:
		return
	var path: String = paths[0]
	var inst: Node3D = ModelLib.instance(path)
	if inst == null:
		return
	# скрыть процедурный котёл, оставить интерактивные тела и жидкость
	for nm in ["StoneRing", "Leg0", "Leg1", "Leg2"]:
		_hide_csg(cauldron.get_node_or_null(nm))
	var pot: Node3D = cauldron.get_node_or_null("Pot") as Node3D
	var fire: Node3D = cauldron.get_node_or_null("Fire") as Node3D
	if pot != null:
		for c in pot.get_children():
			if c is CSGShape3D:
				_hide_csg(c)
	if fire != null:
		for nm2 in ["LogA", "LogB"]:
			_hide_csg(fire.get_node_or_null(nm2))
	cauldron.add_child(inst)
	var ab: AABB = ModelLib.model_aabb(path, inst, meta)
	var s: float = ModelLib.fit(inst, ab, 0.0, CAULDRON_SCALE, 0.0)
	# родная жидкость модели скрывается: цветом зелья управляет игра
	var meshes: Array = []
	ModelLib.collect_meshes(inst, meshes)
	for m in meshes:
		var mi: MeshInstance3D = m
		if String(mi.name).to_lower().find("liquid") != -1 or String(mi.get_parent().name).to_lower().find("liquid") != -1:
			mi.visible = false
	var liquid_y: float = (69.3 - ab.position.y) * s
	var liquid: CSGCylinder3D = cauldron.get_node_or_null("Liquid") as CSGCylinder3D
	if liquid != null:
		liquid.radius = 0.34
		liquid.position.y = liquid_y
	var wc: Node = get_parent()
	if "liquid_y" in wc:
		wc.set("liquid_y", liquid_y)
	var light: Node3D = cauldron.get_node_or_null("CauldronLight") as Node3D
	if light != null:
		light.position.y = liquid_y + 0.8
	# коллизии под реальный размер модели
	if pot != null:
		var shp: CollisionShape3D = pot.get_node_or_null("Shape") as CollisionShape3D
		if shp != null:
			var cyl: CylinderShape3D = CylinderShape3D.new()
			cyl.radius = 0.62
			cyl.height = 0.6
			shp.shape = cyl
		pot.position.y = 0.75
	if fire != null:
		fire.position.y = 0.2
	_add_potion_particles(cauldron, liquid_y)

func _add_potion_particles(parent: Node3D, y: float) -> void:
	# пузырьки зелья
	parent.add_child(_make_particles(y + 0.04, 34, 2.6, 0.3, 0.3, 0.8, 0.13, Color(0.55, 2.2, 0.8, 1.0), 0.0))
	# лёгкий зелёный пар/мерцание
	parent.add_child(_make_particles(y + 0.1, 12, 3.8, 0.28, 0.15, 0.4, 0.55, Color(0.25, 0.9, 0.4, 0.35), 0.0))

func _make_particles(y: float, amount: int, life: float, emit_r: float, vmin: float, vmax: float, quad: float, col: Color, grav_y: float) -> GPUParticles3D:
	var p: GPUParticles3D = GPUParticles3D.new()
	p.position = Vector3(0.0, y, 0.0)
	p.amount = amount
	p.lifetime = life
	p.preprocess = life
	p.visibility_aabb = AABB(Vector3(-1.5, -1.0, -1.5), Vector3(3.0, 4.0, 3.0))
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var pm: ParticleProcessMaterial = ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = emit_r
	pm.direction = Vector3(0.0, 1.0, 0.0)
	pm.spread = 14.0
	pm.initial_velocity_min = vmin
	pm.initial_velocity_max = vmax
	pm.gravity = Vector3(0.0, grav_y, 0.0)
	pm.scale_min = 0.5
	pm.scale_max = 1.3
	var g: Gradient = Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.2, 0.75, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, 1), Color(1, 1, 1, 0.7), Color(1, 1, 1, 0)])
	var gt: GradientTexture1D = GradientTexture1D.new()
	gt.gradient = g
	pm.color_ramp = gt
	p.process_material = pm
	var q: QuadMesh = QuadMesh.new()
	q.size = Vector2(quad, quad)
	q.material = _glow_material(col)
	p.draw_pass_1 = q
	p.emitting = true
	return p

# ------------------------------------------------------------------ altar (саркофаг-алтарь в гроте)
func _build_altar() -> void:
	var paths: Array = catalog.get("altar", [])
	if paths.is_empty():
		return
	var path: String = paths[0]
	var inst: Node3D = ModelLib.instance(path)
	if inst == null:
		return
	var holder: Node3D = Node3D.new()
	holder.name = "RitualAltar"
	holder.position = Vector3(92.0, -10.6, 10.6)
	holder.rotation_degrees = Vector3(0.0, 180.0, 0.0)
	add_child(holder)
	holder.add_child(inst)
	var ab: AABB = ModelLib.model_aabb(path, inst, meta)
	var s: float = ModelLib.fit(inst, ab, 1.25, 0.0, 0.0)
	var body: StaticBody3D = StaticBody3D.new()
	var cs: CollisionShape3D = CollisionShape3D.new()
	var box: BoxShape3D = BoxShape3D.new()
	box.size = ab.size * s
	cs.shape = box
	cs.position = Vector3(0.0, box.size.y * 0.5, 0.0)
	body.add_child(cs)
	holder.add_child(body)
	var fl: Array = meta.get("ritual_altar", {}).get("flames", [])
	for f in fl:
		var fp: Array = f
		_add_flame(holder, Vector3(float(fp[0]), float(fp[1]), float(fp[2])) * 1.25 + Vector3(0.0, 0.1, 0.0), 0.12)
	var light: OmniLight3D = OmniLight3D.new()
	light.light_color = Color(1.0, 0.6, 0.25)
	light.light_energy = 1.1
	light.omni_range = 6.0
	light.position = Vector3(0.0, 2.0, 0.0)
	holder.add_child(light)
	_flicker(light, 1.1)

# ------------------------------------------------------------------ candle holders
func _build_candles() -> void:
	var paths: Array = catalog.get("candle", [])
	if paths.is_empty():
		return
	var path: String = paths[0]
	var spots: Array = [
		Vector3(-2.2, 0.02, 6.4), Vector3(2.2, 0.02, 6.4),     # вход в избу
		Vector3(89.2, -10.6, 2.4), Vector3(89.2, -10.6, 7.6),   # грот у алтаря
	]
	var lit_lights: int = 0
	for i in spots.size():
		var inst: Node3D = ModelLib.instance(path)
		if inst == null:
			return
		var holder: Node3D = Node3D.new()
		holder.name = "CandleHolder%d" % i
		holder.position = spots[i]
		add_child(holder)
		holder.add_child(inst)
		var ab: AABB = ModelLib.model_aabb(path, inst, meta)
		var s: float = ModelLib.fit(inst, ab, CANDLE_HEIGHT, 0.0, 0.0)
		ModelLib.add_cylinder_body(holder, Vector3.ZERO, 0.16, CANDLE_HEIGHT)
		var fl: Array = meta.get("candle_holder", {}).get("flames", [])
		for f in fl:
			var fp: Array = f
			_add_flame(holder, Vector3(float(fp[0]), float(fp[1]), float(fp[2])) * CANDLE_HEIGHT + Vector3(0.0, 0.07, 0.0), 0.09)
		if lit_lights < 4:
			var lt: OmniLight3D = OmniLight3D.new()
			lt.light_color = Color(1.0, 0.65, 0.3)
			lt.light_energy = 0.9
			lt.omni_range = 5.0
			lt.position = Vector3(0.0, CANDLE_HEIGHT + 0.15, 0.0)
			holder.add_child(lt)
			_flicker(lt, 0.9)
			lit_lights += 1

# ------------------------------------------------------------------ финал
func on_finale(duration: float) -> void:
	if tree_mat != null:
		var tw: Tween = create_tween()
		tw.tween_method(func(v: float) -> void: tree_mat.set_shader_parameter("tint", Color(0.52, 0.52, 0.66).lerp(Color(1.05, 1.0, 0.8), v)), 0.0, 1.0, duration)
