import sys,os,json,io,shutil
sys.path.insert(0,'/home/claude/build')
from gltfutil import *
UP='/home/claude/up';OUT='/home/claude/proj/baba_yaga_3d_v2/assets/custom/models'
os.makedirs(OUT,exist_ok=True)
meta={}
def normalize(P,center='base',rot_y90=False):
    if rot_y90: P=np.stack([P[:,2],P[:,1],-P[:,0]],1)
    mn=P.min(0);h=P[:,1].max()-mn[1]
    if center=='base':
        m=P[:,1]<mn[1]+0.02*h;c=P[m][:,[0,2]].mean(0)
    else: c=(P.max(0)[[0,2]]+mn[[0,2]])/2
    Q=P.copy();Q[:,0]-=c[0];Q[:,2]-=c[1];Q[:,1]-=mn[1]
    return Q/h,h,c,mn[1]
def cluster_tops(pts,rad,maxn):
    pts=pts[np.argsort(-pts[:,1])];res=[];used=np.zeros(len(pts),bool)
    for i in range(len(pts)):
        if used[i]: continue
        d=np.hypot(pts[:,0]-pts[i,0],pts[:,2]-pts[i,2]);g=(d<rad)&(~used);used|=g
        res.append((int(g.sum()),pts[i]))
    res.sort(key=lambda r:-r[0]);return [r[1] for r in res[:maxn]]
# ---------- TREE
g=G(UP+'/old_tree_3d_model_free');P,C,F,_=merged_mesh(g)
print('tree raw',len(P),len(F))
P0,C0,F0=decimate_to(P,C,F,6500);print('tree lod0',len(F0))
Pn,h,c,y0=normalize(P0,'base');N=vertex_normals(Pn,F0)
write_glb(OUT+'/dead_tree_lod0.glb',Pn,N,C0,F0,'DeadTree')
m=(Pn[:,1]>0.08)&(Pn[:,1]<0.22);tr=float(np.hypot(Pn[m][:,0],Pn[m][:,2]).mean()) if m.sum() else 0.06
meta['dead_tree']={'trunk_r':tr,'aspect':float(np.ptp(Pn[:,0])/1.0)}
P1,C1,F1=decimate_to(Pn,C0,F0,900);print('tree lod1',len(F1))
write_glb(OUT+'/dead_tree_lod1.glb',P1,vertex_normals(P1,F1),C1,F1,'DeadTreeLOD')
# ---------- CANDLE HOLDER
g=G(UP+'/long_candle_holder_rusty');P,C,F,M=merged_mesh(g)
cm=[i for i,m_ in enumerate(g.g['materials']) if m_['name']=='Candle_T'][0]
raw_candle=P[M==cm]
P0,C0,F0=decimate_to(P,C,F,5500);print('candle',len(F0))
Pn,h,c,y0=normalize(P0,'bbox')
rc=raw_candle.copy();rc[:,0]-=c[0];rc[:,2]-=c[1];rc[:,1]-=y0;rc/=h
flames=cluster_tops(rc,0.045,8)
write_glb(OUT+'/candle_holder.glb',Pn,vertex_normals(Pn,F0),C0,F0,'CandleHolder')
meta['candle_holder']={'flames':[[float(p[0]),float(p[1]),float(p[2])] for p in flames],'aspect':float(max(np.ptp(Pn[:,0]),np.ptp(Pn[:,2])))}
# ---------- ALTAR
g=G(UP+'/gothic_candle_altar_wax_ritual_book_1');P,C,F,_=merged_mesh(g)
print('altar raw',len(P),len(F))
P0,C0,F0=decimate_to(P,C,F,16000);print('altar',len(F0))
Pn,h,c,y0=normalize(P0,'bbox',rot_y90=True)
luma=(C0*np.array([.2126,.7152,.0722])).sum(1)
sel=(luma>0.35)&(Pn[:,1]>0.8)
fl=cluster_tops(Pn[sel],0.05,5) if sel.sum() else []
write_glb(OUT+'/ritual_altar.glb',Pn,vertex_normals(Pn,F0),C0,F0,'RitualAltar')
meta['ritual_altar']={'flames':[[float(p[0]),float(p[1]),float(p[2])] for p in fl],'length':float(np.ptp(Pn[:,0])),'width':float(np.ptp(Pn[:,2]))}
# ---------- REPACK (house, witch, cauldron)
def repack(src,dst,maxtex=1024,keep_emissive=True):
    g=G(UP+'/'+src);js=g.g;binb=bytearray(g.buf)
    used={}
    def reg(ti,kind):
        key=(ti,kind)
        if key not in used: used[key]=len(used)
        return used[key]
    for m in js.get('materials',[]):
        pb=m.setdefault('pbrMetallicRoughness',{})
        pb.pop('metallicRoughnessTexture',None);m.pop('normalTexture',None);m.pop('occlusionTexture',None)
        pb['metallicFactor']=0.0;pb['roughnessFactor']=0.9
        if 'baseColorTexture' in pb: pb['baseColorTexture']['index']=reg(pb['baseColorTexture']['index'],'c')
        if 'emissiveTexture' in m:
            if keep_emissive: m['emissiveTexture']['index']=reg(m['emissiveTexture']['index'],'e')
            else: m.pop('emissiveTexture')
        m.get('extensions',{}).clear();m.pop('extensions',None)
    new_tex=[];new_img=[];views=js['bufferViews']
    for (ti,kind),k in sorted(used.items(),key=lambda kv:kv[1]):
        src_img=js['textures'][ti]['source'];im=g.image(src_img).convert('RGB')
        im.thumbnail((maxtex if kind=='c' else 512,)*2)
        bio=io.BytesIO();im.save(bio,'JPEG',quality=86);b=bio.getvalue()
        while len(binb)%4: binb.append(0)
        views.append({'buffer':0,'byteOffset':len(binb),'byteLength':len(b)});binb+=b
        new_img.append({'bufferView':len(views)-1,'mimeType':'image/jpeg'})
        t={'source':len(new_img)-1}
        if 'sampler' in js['textures'][ti]: t['sampler']=js['textures'][ti]['sampler']
        new_tex.append(t)
    js['textures']=new_tex;js['images']=new_img
    js.pop('extensionsUsed',None);js.pop('extensionsRequired',None)
    js['buffers']=[{'byteLength':len(binb)}]
    pack_glb(OUT+'/'+dst,js,bytes(binb))
repack('witchhouse__sherwood--forest','witch_house.glb',1024)
repack('witch','witch.glb',1024)
repack('stylized_halloween_cauldron','cauldron.glb',1024)
# sky
from PIL import Image
im=Image.open(UP+'/free_-_skybox_pack_fantasy_swamplands/textures/material_1_baseColor.jpeg').convert('RGB').resize((2048,1024))
im.save(OUT+'/../sky_swamp.jpg',quality=80)
json.dump(meta,open(OUT+'/models_meta.json','w'),indent=1)
print(meta)
for f in sorted(os.listdir(OUT)): print(f,os.path.getsize(OUT+'/'+f)//1024,'KB')
