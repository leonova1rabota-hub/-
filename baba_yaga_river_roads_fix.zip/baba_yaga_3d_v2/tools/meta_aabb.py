import sys,json,struct,numpy as np
sys.path.insert(0,'/home/claude/build')
from gltfutil import node_matrix,CT,NC
D='/home/claude/proj/baba_yaga_3d_v2/assets/custom/models/'
def loadglb(p):
    b=open(p,'rb').read();jl=struct.unpack('<I',b[12:16])[0];return json.loads(b[20:20+jl]),b[20+jl+8:]
def aabb(p):
    js,bin_=loadglb(p)
    def acc(i):
        a=js['accessors'][i];v=js['bufferViews'][a['bufferView']];dt=CT[a['componentType']];nc=NC[a['type']]
        off=v.get('byteOffset',0)+a.get('byteOffset',0);st=v.get('byteStride',0);es=np.dtype(dt).itemsize*nc
        if st and st!=es:
            raw=np.frombuffer(bin_,dtype=np.uint8,count=st*a['count'],offset=off).reshape(a['count'],st);return raw[:,:es].copy().view(dt).reshape(a['count'],nc)
        return np.frombuffer(bin_,dtype=dt,count=a['count']*nc,offset=off).reshape(a['count'],nc)
    world={}
    def rec(i,P):
        M=P@node_matrix(js['nodes'][i]);world[i]=M
        for c in js['nodes'][i].get('children',[]): rec(c,M)
    for s in js['scenes'][0]['nodes']: rec(s,np.eye(4))
    mn=np.array([1e9]*3);mx=-mn.copy()
    for i,n in enumerate(js['nodes']):
        if 'mesh' not in n: continue
        for pr in js['meshes'][n['mesh']]['primitives']:
            pos=acc(pr['attributes']['POSITION']).astype(np.float64);H=np.concatenate([pos,np.ones((len(pos),1))],1)
            if 'skin' in n and 'JOINTS_0' in pr['attributes']:
                sk=js['skins'][n['skin']];ibm=acc(sk['inverseBindMatrices']).reshape(-1,4,4).astype(np.float64)
                J=acc(pr['attributes']['JOINTS_0']).astype(int);Wt=acc(pr['attributes']['WEIGHTS_0']).astype(np.float64)
                if Wt.max()>1.5: Wt/=255.0
                jm=np.array([world[j]@ibm[k].T for k,j in enumerate(sk['joints'])])
                out=np.zeros((len(pos),3))
                for k in range(4):
                    m=jm[J[:,k]];out+=Wt[:,k:k+1]*np.einsum('nij,nj->ni',m,H)[:,:3]
                V=out
            else: V=(world[i]@H.T).T[:,:3]
            mn=np.minimum(mn,V.min(0));mx=np.maximum(mx,V.max(0))
    return mn,mx
meta=json.load(open(D+'models_meta.json'))
for f in ['dead_tree_lod0','dead_tree_lod1','candle_holder','ritual_altar','witch_house','witch','cauldron']:
    mn,mx=aabb(D+f+'.glb');meta.setdefault('aabb',{})[f]=[mn.round(4).tolist(),mx.round(4).tolist()]
    print(f,mn.round(2),mx.round(2),(mx-mn).round(2))
json.dump(meta,open(D+'models_meta.json','w'),indent=1)
