import sys,os,json,io,shutil
sys.path.insert(0,'/home/claude/build')
from gltfutil import *
UP='/home/claude/up';OUT='/home/claude/proj/baba_yaga_3d_v2/assets/custom/models'
os.makedirs(OUT,exist_ok=True)
def normalize(P,center='base',rot_y90=False):
    if rot_y90: P=np.stack([P[:,2],P[:,1],-P[:,0]],1)
    mn=P.min(0);h=P[:,1].max()-mn[1]
    if center=='base':
        m=P[:,1]<mn[1]+0.02*h;c=P[m][:,[0,2]].mean(0)
    else: c=(P.max(0)[[0,2]]+mn[[0,2]])/2
    Q=P.copy();Q[:,0]-=c[0];Q[:,2]-=c[1];Q[:,1]-=mn[1]
    return Q/h,h,c,mn[1]
def cluster_tops(pts,rad,maxn):
    pts=pts[np.argsort(-pts[:,1])];res=[];used=np.zeros(len(pts),bool)
    for i in range(len(pts)):
        if used[i]: continue
        d=np.hypot(pts[:,0]-pts[i,0],pts[:,2]-pts[i,2]);g=(d<rad)&(~used);used|=g
        res.append((int(g.sum()),pts[i]))
    res.sort(key=lambda r:-r[0]);return [r[1] for r in res[:maxn]]

def repack(src,dst,maxtex=1024,keep_emissive=True):
    g=G(UP+'/'+src);js=g.g;binb=bytearray(g.buf)
    used={}
    def reg(ti,kind):
        key=(ti,kind)
        if key not in used: used[key]=len(used)
        return used[key]
    for m in js.get('materials',[]):
        pb=m.setdefault('pbrMetallicRoughness',{})
        pb.pop('metallicRoughnessTexture',None);m.pop('normalTexture',None);m.pop('occlusionTexture',None)
        pb['metallicFactor']=0.0;pb['roughnessFactor']=0.9
        if 'baseColorTexture' in pb: pb['baseColorTexture']['index']=reg(pb['baseColorTexture']['index'],'c')
        if 'emissiveTexture' in m:
            if keep_emissive: m['emissiveTexture']['index']=reg(m['emissiveTexture']['index'],'e')
            else: m.pop('emissiveTexture')
        m.get('extensions',{}).clear();m.pop('extensions',None)
    new_tex=[];new_img=[];views=js['bufferViews']
    for (ti,kind),k in sorted(used.items(),key=lambda kv:kv[1]):
        src_img=js['textures'][ti]['source'];im=g.image(src_img).convert('RGB')
        im.thumbnail((maxtex if kind=='c' else 512,)*2)
        bio=io.BytesIO();im.save(bio,'JPEG',quality=86);b=bio.getvalue()
        while len(binb)%4: binb.append(0)
        views.append({'buffer':0,'byteOffset':len(binb),'byteLength':len(b)});binb+=b
        new_img.append({'bufferView':len(views)-1,'mimeType':'image/jpeg'})
        t={'source':len(new_img)-1}
        if 'sampler' in js['textures'][ti]: t['sampler']=js['textures'][ti]['sampler']
        new_tex.append(t)
    js['textures']=new_tex;js['images']=new_img
    js.pop('extensionsUsed',None);js.pop('extensionsRequired',None)
    js['buffers']=[{'byteLength':len(binb)}]
    pack_glb(OUT+'/'+dst,js,bytes(binb))
